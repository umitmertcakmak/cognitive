from setuptools import setup

VERSION='0.1.0-201704240355'
setup(name='ml-algorithms',
      version=VERSION,
      description='WML algorithms',
      url='https://github.ibm.com/NGP-TWC/ml-algorithms',
      author='IBM',
      author_email='ibm@ibm.com',
      license='IBM',
      packages=['cadspy', 'hpopy', 'adppy', 'features'],
      zip_safe=False)
