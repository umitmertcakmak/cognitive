################################################################################
# IBM Confidential
# OCO Source Materials
# (c) Copyright IBM Corp. 2017
# US Government Users Restricted Rights - Use, duplication disclosure restricted
# by GSA ADP Schedule Contract with IBM Corp.
################################################################################
'''
Created on Nov 28, 2016

@author: calin
'''

import logging

from pyspark import keyword_only
from pyspark.ml.common import inherit_doc
from pyspark.ml.wrapper import JavaEstimator, JavaModel, JavaTransformer

from adppy.adpparam import ADPParams
from features.mlencoder import JavaMLEncoder

logger = logging.getLogger("ml-algorithms")


@inherit_doc
class ADP(JavaEstimator, ADPParams, JavaMLEncoder):
    '''
    classdocs
    '''

    @keyword_only
    def __init__(self, randomSeed=1234324, isClassification=False, sampleSize=10000, useFeatureNorm=True,
                 inputCols=None, excludedCols=[], numericCategoricalCols=[], labelCol="label", featuresCol='features',
                 maxCategories=100, nullStringVal="$null", labelEncodedCol="label", decodedField="label_class",
                 predictionField="prediction", autoFieldsDiscovery=False, handleInvalid="error"):
        '''
        Constructor
        '''
        super(ADP, self).__init__()
        self._java_obj = self._new_java_obj("com.ibm.analytics.wml.features.ADP", self.uid)
        self._setDefault(randomSeed=1234324, isClassification=False, sampleSize=10000, useFeatureNorm=True,
                         inputCols=None, excludedCols=[], numericCategoricalCols=[], labelCol="label",
                         featuresCol='features',
                         maxCategories=100, nullStringVal="$null", labelEncodedCol="label", decodedField="label_class",
                         predictionField="prediction", autoFieldsDiscovery=False, handleInvalid="error")
        kwargs = self.__init__._input_kwargs
        self.setParams(**kwargs)

    def _create_model(self, java_model):
        return ADPModel(java_model)

    def _create_decoder(self, java_model):
        return ADPDecoder(java_model)

    @keyword_only
    def setParams(self, randomSeed=1234324, isClassification=False, sampleSize=10000, useFeatureNorm=True,
                  inputCols=None, excludedCols=[], numericCategoricalCols=[], labelCol="label", featuresCol='features',
                  maxCategories=100, nullStringVal="$null", labelEncodedCol="label", decodedField="label_class",
                  predictionField="prediction", autoFieldsDiscovery=False, handleInvalid="error"):
        kwargs = self.setParams._input_kwargs
        return self._set(**kwargs)


class ADPModel(JavaModel):
    """
    ADP Model 
    """


class ADPDecoder(JavaTransformer):
    """
    ADP Decoder
    """
