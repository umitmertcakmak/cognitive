################################################################################
# IBM Confidential
# OCO Source Materials
# (c) Copyright IBM Corp. 2017
# US Government Users Restricted Rights - Use, duplication disclosure restricted
# by GSA ADP Schedule Contract with IBM Corp.
################################################################################
'''
Created on Nov 28, 2016

@author: calin
'''

from pyspark.ml.param import *


class ADPParams(Params):
    '''
    ADP algorithms parameters class
    '''

    randomSeed = Param(Params._dummy(), "randomSeed", "the random seed used when sampling data",
                       typeConverter=TypeConverters.toInt)
    isClassification = Param(Params._dummy(), "isClassification", "is this a classification or regression problem?",
                             typeConverter=TypeConverters.toBoolean)
    sampleSize = Param(Params._dummy(), "sampleSize", "the sample size for the first iteration",
                       typeConverter=TypeConverters.toInt)
    useFeatureNorm = Param(Params._dummy(), "useFeatureNorm",
                                    "enable / disable feature normalization",
                                    typeConverter=TypeConverters.toBoolean)
    inputCols = Param(Params._dummy(), "inputCols", "input column names.", typeConverter=TypeConverters.toListString)
    excludedCols = Param(Params._dummy(), "excludedCols", "excluded column names.", typeConverter=TypeConverters.toListString)
    numericCategoricalCols = Param(Params._dummy(), "numericCategoricalCols", "numeric columns that will be treated as categorical.", typeConverter=TypeConverters.toListString)
    labelCol = Param(Params._dummy(), "labelCol", "label column name", typeConverter=TypeConverters.toString)
    featuresCol = Param(Params._dummy(), "featuresCol", "features column name.", typeConverter=TypeConverters.toString)
    maxCategories = Param(Params._dummy(), "maxCategories",
                          "maximum number of distincts categories allowed for a single categorical field",
                          typeConverter=TypeConverters.toInt)
    nullStringVal = Param(Params._dummy(), "nullStringVal", "the representation of empty string values",
                          typeConverter=TypeConverters.toString)
    labelEncodedCol = Param(Params._dummy(), "labelEncodedCol",
                            "encoded/indexed label field name used as \"label\" input column in ML algorithm",
                            typeConverter=TypeConverters.toString)
    autoFieldsDiscovery = Param(Params._dummy(), "autoFieldsDiscovery", "use all supported input fields available in input dataFrame except label field",
                                typeConverter=TypeConverters.toBoolean)
    handleInvalid = Param(Params._dummy(), "handleInvalid", "how to handle invalid entries. Options are skip (which will filter out rows with bad values), or error (which will throw an error). More options may be added later",
                          typeConverter=TypeConverters.toString)
    def __init__(self):
        '''
        Constructor
        '''
        super(ADPParams, self).__init__()

        self._setDefault(randomSeed=1234324, isClassification=False, sampleSize=10000, useFeatureNorm=True,
                         inputCols=None, excludedCols=[],numericCategoricalCols=[], labelCol="label", featuresCol='features',
                         maxCategories=100, nullStringVal="$null", labelEncodedCol="label",
                         decodedField="label_class", predictionField="prediction", autoFieldsDiscovery=False,
                         handleInvalid="error")

    def setRandomSeed(self, value):
        """
        Sets the value of :py:attr:`randomSeed`.

        >>> algo = ADPEstimator().setRandomSeed(1234324)
        >>> algo.getRandomSeed()
        10
        """
        self._set(randomSeed=value)
        return self

    def getRandomSeed(self):
        """
        Gets the value of `randomSeed`
        """
        return self.getOrDefault(self.randomSeed)

    def setIsClassificationProblem(self):
        """
        Sets the value of :py:attr:`isClassification`.

        >>> algo = ADPEstimator().setIsClassificationProblem()
        >>> algo.isClassification()
        True
        """
        self._set(isClassification=True)
        return self

    def isClassificationProblem(self):
        """
        Gets the value of `isClassification`
        """
        return self.getOrDefault(self.isClassification)

    def setSampleSize(self, value):
        """
        Sets the value of :py:attr:`sampleSize`.

        >>> algo = ADPEstimator().setSampleSize(500)
        >>> algo.getSampleSize()
        500
        """
        self._set(sampleSize=value)
        return self

    def getSampleSize(self):
        """
        Gets the value of `sampleSize`
        """
        return self.getOrDefault(self.sampleSize)

    def setUseFeatureNormalization(self, value):
        """
        Sets the value of :py:attr:`useFeatureNorm`.

        >>> algo = ADPEstimator().setUseFeatureNormalization(False)
        >>> algo.useFeatureNormalization()
        False
        """
        self._set(useFeatureNorm=value)
        return self

    def useFeatureNormalization(self):
        """
        Gets the value of `useFeatureNorm`
        """
        return self.getOrDefault(self.useFeatureNorm)

    def setInputCols(self, value):
        """
        Sets the value of :py:attr:`inputCols`.
        """
        return self._set(inputCols=value)

    def getInputCols(self):
        """
        Gets the value of inputCols or its default value.
        """
        return self.getOrDefault(self.inputCols)

    def setExcludedCols(self, value):
        """
        Sets the value of :py:attr:`excludedCols`.
        """
        return self._set(excludedCols=value)

    def getExcludedCols(self):
        """
        Gets the value of excludedCols or its default value.
        """
        return self.getOrDefault(self.excludedCols)

    def setNumericCategoricalCols(self, value):
        """
        Sets the value of :py:attr:`numericCategoricalCols`.
        """
        return self._set(numericCategoricalCols=value)

    def getNumericCategoricalCols(self):
        """
        Gets the value of numericCategoricalCols or its default value.
        """
        return self.getOrDefault(self.numericCategoricalCols)

    def setLabelCol(self, value):
        """
        Sets the value of :py:attr:`labelCol`.
        """
        return self._set(labelCol=value)

    def getLabelCol(self):
        """
        Gets the value of labelCol or its default value.
        """
        return self.getOrDefault(self.labelCol)

    def setFeaturesCol(self, value):
        """
        Sets the value of :py:attr:`featuresCol`.
        """
        return self._set(featuresCol=value)

    def getFeaturesCol(self):
        """
        Gets the value of featuresCol or its default value.
        """
        return self.getOrDefault(self.featuresCol)

    def setMaxCategories(self, value):
        """
        Sets the value of :py:attr:`maxCategories`.
        """
        return self._set(maxCategories=value)

    def getMaxCategorie(self):
        """
        Gets the value of `maxCategories`
        """
        return self.getOrDefault(self.maxCategories)

    def setNullStringVal(self, value):
        """
        Sets the value of :py:attr:`nullStringVal`.
        """
        return self._set(nullStringVal=value)

    def getNullStringVal(self):
        """
        Gets the value of `nullStringVal`
        """
        return self.getOrDefault(self.nullStringVal)

    def setLabelEncodedColName(self, value):
        """
        Sets the value of :py:attr:`labelEncodedCol`.
        """

        return self._set(labelEncodedCol=value)

    def getLabelEncodedCol(self):
        """
        Gets the value of `labelEncodedCol`
        """
        return self.getOrDefault(self.labelEncodedCol)

    def setAutomaticFieldsDiscovery(self, value):
        """

        :param value: set true to use all supported input fields available in input dataFrame except label field
        :return: self
        """
        return self._set(autoFieldsDiscovery=value)

    def getAutomaticFieldsDiscovery(self):
        """
        :return: true if use all supported input fields available in input dataFrame except label field
        """
        return self.getOrDefault(self.autoFieldsDiscovery)

    def setHandleInvalid(self, value):
        """

        :param value: set the way ADP is handling categorical fields in scoring that does not have a corresponding value in model categories
        :return:  self
        """
        return self._set(handleInvalid=value)


    def getHandleInvalid(self):
        """
        :return: how to handle invalid entries. Options are skip (which will filter out rows with bad values), or error (which will throw an error). More options may be added later
        """
        return self.getOrDefault(self.handleInvalid)
