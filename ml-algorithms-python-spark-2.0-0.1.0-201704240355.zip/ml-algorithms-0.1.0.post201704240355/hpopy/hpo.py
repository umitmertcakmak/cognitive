################################################################################
# IBM Confidential
# OCO Source Materials
# (c) Copyright IBM Corp. 2017
# US Government Users Restricted Rights - Use, duplication disclosure restricted
# by GSA ADP Schedule Contract with IBM Corp.
################################################################################
'''
Created on Aug 2, 2016

@author: calin
'''

import logging
import multiprocessing
from py4j.java_collections import ListConverter
from pyspark import SparkContext
from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pyspark.ml.param import Param, Params
from pyspark import  keyword_only
from pyspark.ml.wrapper import  _jvm
from pyspark.ml.wrapper import JavaEstimator, JavaModel
from pyspark.ml.common import inherit_doc, _py2java

from cadspy.cadsparam import CadsParams
from cadspy.iterationhook import _IterationProxy
from cadspy.learner import Learner


logger = logging.getLogger("ml-algorithms")


@inherit_doc
class HPOEstimator(JavaEstimator, CadsParams):
    '''
    classdocs
    '''
    
    learner = Param(Params._dummy(), "learner", "Learner parameters")
    hyperSetings = Param(Params._dummy(), "hyperSetings", "Hyper Settings")
    learner = Learner._dummy()

    @keyword_only
    def __init__(self, randomSeed=1, dataGrowthFactor=1.5, initialSampleSize=500, numSampleFolds=3, maxNumPointsForPrediction=5, keepBestNLearners=3, evaluator=None, maxParallelEstimators=multiprocessing.cpu_count(), learner=None):
        '''
        Constructor
        '''
        super(HPOEstimator, self).__init__() 
        self._java_obj = self._new_java_obj("com.ibm.analytics.wml.hpo.HPOEstimator", self.uid)
        self.learner = Param(self, "learner", "Learner Parameter")
        self.hyperSetings = Param(self, "hyperSetings", "Hyper Settings Parameter")
        self._setDefault(randomSeed=1, dataGrowthFactor=1.5, initialSampleSize=500, numSampleFolds=3, maxNumPointsForPrediction=5, keepBestNLearners=3, evaluator=BinaryClassificationEvaluator().setMetricName("areaUnderROC"), maxParallelEstimators=multiprocessing.cpu_count(), learner=None)
        kwargs = self.__init__._input_kwargs
        self.setParams(**kwargs)
        self._updateDefaultEvaluator()
     
    def _create_model(self, java_model):
        return HPOModel(java_model)
    
    def _fit_java(self, dataset):
        """
        Fits a Java model to the input dataset.
 
        :param dataset: input dataset, which is an instance of
                        :py:class:`pyspark.sql.DataFrame`
        :param params: additional params (overwriting embedded values)
        :return: fitted Java model
        """
        try:
            self._updateCustomParams()
            self._transfer_params_to_java()
            return self._java_obj.fit(dataset._jdf)
        except Exception,e:
            logger.exception(e)
            raise
    
    @keyword_only
    def setParams(self, randomSeed=1, dataGrowthFactor=1.5, initialSampleSize=500, numSampleFolds=3, maxNumPointsForPrediction=5, keepBestNLearners=3, maxParallelEstimators=multiprocessing.cpu_count(), learner=None):
        kwargs = self.setParams._input_kwargs
        return self._set(**kwargs)
    
    def stop(self):
        logger.info("HPO instance was stopped")
        self._java_obj.stop()

    def withIterationHook(self, hook):
        _jProxyObj = _jvm().com.ibm.analytics.wml.pythonbinding.IterationProxy
        hookProxy = _IterationProxy(hook)
        
        sHookProxy = _jProxyObj.toIterationHookProxy(hookProxy)
        self._java_obj = self._java_obj.withIterationHook(sHookProxy)
        return self
    
    def setLearner(self, value):
        """
        Sets the value of :py:attr:`learner`.
        >>> algo = CADSEstimator().setLearner([ Learner("LR", LogisticRegression(maxIter=10, regParam=0.01), )])
        
        """
        self._learner = value
        return self
    
    def setHyperSettings(self, value):
        """
        Sets the value of :py:attr:`hyperSetings`.

        >>> algo = HPOEstimator().setHyperSettings([{param:value}, {param:value}])
        10
        """
        self._hyperSettings = value
        return self
    
    def _updateCustomParams(self):
        super(HPOEstimator, self)._updateCustomParams()
        sc = SparkContext.getOrCreate()
        jvmObject = _jvm()
        self._paramMap[self.learner] = self._learner.to_learner_java_object()
        _jToScalaList = jvmObject.com.ibm.analytics.wml.pythonbinding.Helper.javaToScalaList
        pParamsMaps = [self.buildScalaParamsMap(jvmObject, item) for item in self._hyperSettings]
        jParamsMaps = ListConverter().convert(pParamsMaps, sc._gateway._gateway_client)
        sParamsMaps = _jToScalaList(jParamsMaps)

        self._paramMap[self.hyperSetings] = sParamsMaps
        
    @classmethod
    def buildScalaParamsMap(cls, jvmObject, inputParamsMap):
        sc = SparkContext.getOrCreate()
        paramMapConstructor = jvmObject.org.apache.spark.ml.param.ParamMap
        jParamMap = paramMapConstructor()
        _jToScalaList = jvmObject.com.ibm.analytics.wml.pythonbinding.Helper.javaToScalaList
        paramConstructor = jvmObject.org.apache.spark.ml.param.Param
        
        for param in inputParamsMap:
            jParamItem = paramConstructor(param.parent, str(param.name), str(param.doc))
            java_value = _py2java(sc, inputParamsMap[param])
            jPair = jParamItem.w(java_value)
            pListPairs = [jPair]
            jListPairs = ListConverter().convert(pListPairs, sc._gateway._gateway_client)
            sListPairs = _jToScalaList(jListPairs)
            jParamMap.put(sListPairs)
        return jParamMap
        
class HPOModel(JavaModel):
    """
    HPO Model 
    """
