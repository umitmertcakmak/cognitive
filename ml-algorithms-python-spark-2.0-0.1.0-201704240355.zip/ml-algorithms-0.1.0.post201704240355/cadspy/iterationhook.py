################################################################################
# IBM Confidential
# OCO Source Materials
# (c) Copyright IBM Corp. 2017
# US Government Users Restricted Rights - Use, duplication disclosure restricted
# by GSA ADP Schedule Contract with IBM Corp.
################################################################################
'''
Created on Jul 22, 2016

@author: calin
'''

import logging
from pyspark.ml.wrapper import  _jvm

from cadspy.learner import Learner
from pyspark.mllib.classification import LabeledPoint 
from pyspark.mllib.linalg import Vectors


logger = logging.getLogger("ml-algorithms")

__all__ = ['IterationHook', 'History']

class IterationHook(object):
    '''
    Pair class used in CADS as Iteration hook
    '''

    def __init__(self):
        '''
        Constructor for IterationHook object
        '''
    
    def __str__(self):
        return "Iteration Hook"
    
    def toString(self):
        return str(self)
    
    def notify(self, num, pHistories):
        logger.info("Run Iteration %d , history size: %d", num, len(pHistories))
        pass


def _javaIterGenerator(jIter):
    while jIter.hasNext():
        yield jIter.next()
        
        
class _IterationProxy(object):
    '''
    Pair class used internally in CADS as Iteration proxy 
    '''

    def __init__(self, iterationHook):
        '''
        Constructor for _IterationProxy object
        '''
        self._realHook = iterationHook
    
    def __str__(self):
        return "Iteration Proxy"
    
    def toString(self):
        return str(self)
    
    def notify(self, num, jhistories):
        try:
            if (jhistories is not None):
                pHistoryCol = []
                for item in jhistories:
                    pHistoryCol.append(History(item))
                self._realHook.notify(num, pHistoryCol)
            else:
                self._realHook.notify(num, [])
            
        except Exception, e:
            logger.exception(e)
            raise 

    class Java:
        implements = ['com.ibm.analytics.wml.pythonbinding.IterationNotifiable']

class History(object):
    # TODO this class needs to be extended to transform all scala , java object in Python Wrappers 
    '''
       Constructor for _IterationProxy object
    '''
    def __init__(self, jHistoryInstance):
        self._jHistory = jHistoryInstance
        
    def get_learner(self):
        jLearner = self._jHistory.learner()
        return Learner(str(jLearner.name()), None, None)
     
    def get_model(self):
        return self._jHistory.model()
    
    def get_prediction(self):
        rawPrediction = self._jHistory.prediction()
        if rawPrediction.isEmpty():
            return None
        else:
            return rawPrediction.get()
    
    def get_points(self):
        sPoints = self._jHistory.points()
        if sPoints is not None:
            jvmObject = _jvm()
            _jpointsList = jvmObject.com.ibm.analytics.wml.pythonbinding.Helper.scalaToJavaList(sPoints)
            pLabelPointsList = []
            for jLabeledPoint in _jpointsList:
                label = jLabeledPoint.label()
                features = jLabeledPoint.features()
                size = features.size()
                featuresCol = []
                for index in range(0, size):
                    featuresCol.append(features.apply(index))
                pLabelPointsList.append(LabeledPoint(label, Vectors.dense(*featuresCol)))
            return pLabelPointsList
        else:
            return []
        
     
    

