################################################################################
# IBM Confidential
# OCO Source Materials
# (c) Copyright IBM Corp. 2017
# US Government Users Restricted Rights - Use, duplication disclosure restricted
# by GSA ADP Schedule Contract with IBM Corp.
################################################################################
'''
Created on Jul 15, 2016

@author: calin
'''

import multiprocessing
from pyspark import SparkContext 
from pyspark.ml.evaluation import BinaryClassificationEvaluator, JavaEvaluator
from pyspark.ml.param import Param, Params
from pyspark.ml.wrapper import  _jvm
from py4j.java_collections import ListConverter

from cadspy.learner import CADSEvaluatorWrapper, CADSTransformerWrapper


class CadsParams(Params):
    '''
    CADS algorithms parameters class
    '''
    
    randomSeed = Param(Params._dummy(), "randomSeed", "The random seed used when sampling data on each iteration")
    dataGrowthFactor = Param(Params._dummy(), "dataGrowthFactor", "The ratio for the geometric progression used for sample growth on each iteration.")
    initialSampleSize = Param(Params._dummy(), "initialSampleSize", "The sample size for the first iteration")
    numSampleFolds = Param(Params._dummy(), "numSampleFolds", "The number of training/validation pairs used for each learner.")
    maxNumPointsForPrediction = Param(Params._dummy(), "numSampleFolds", "The max number of (metric. data_size) points used for predicting the metric for the full data set.")
    keepBestNLearners = Param(Params._dummy(), "keepBestNLearners", "The number of best learners that would be evaluated on the net iteration.")
    evaluator = Param(Params._dummy(), "evaluator", "The evaluator instance to use for computing the model evaluation metric")
    maxParallelEstimators = Param(Params._dummy(), "maxParallelEstimators", "The number of estimators that can run in parallel")
    target = Param(Params._dummy(), "target", "The target field specification")
    combinatorialTransformers = Param(Params._dummy(), "combinatorialTransformers", "The set of transformers that will be combined with the set of learners. All combinations of (transformer, learner) will be tried.")
    _combinatorialTransformers = []

    def __init__(self):
        '''
        Constructor
        '''
        super(CadsParams, self).__init__()
        self.randomSeed = Param(self, "randomSeed", "The random seed used when sampling data on each iteration")
        self.dataGrowthFactor = Param(self, "dataGrowthFactor", "The ratio for the geometric progression used for sample growth on each iteration.")
        self.initialSampleSize = Param(self, "initialSampleSize", "The sample size for the first iteration")
        self.numSampleFolds = Param(self, "numSampleFolds", "he number of training/validation pairs used for each learner.")
        self.maxNumPointsForPrediction = Param(self, "numSampleFolds", "The max number of (metric. data_size) points used for predicting the metric for the full data set.")
        self.keepBestNLearners = Param(self, "keepBestNLearners", "The number of best learners that would be evaluated on the net iteration.")
        self.evaluator = Param(self, "evaluator", "Evaluators  - Learner")
        self.maxParallelEstimators = Param(self, "maxParallelEstimators", "The evaluator instance to use for computing the model evaluation metric")
        self.target = Param(self, "target", "The target field specification")
        self.combinatorialTransformers = Param(self, "combinatorialTransformers", "The set of transformers that will be combined with the set of learners. All combinations of (transformer, learner) will be tried.")
        self._setDefault(randomSeed=1, dataGrowthFactor=1.5, initialSampleSize=500, numSampleFolds=3, maxNumPointsForPrediction=5, keepBestNLearners=3, evaluator=BinaryClassificationEvaluator().setMetricName("areaUnderROC"), maxParallelEstimators=multiprocessing.cpu_count(), combinatorialTransformers=[])

    def setRandomSeed(self, value):
        """
        Sets the value of :py:attr:`randomSeed`.

        >>> algo = CADSEstimator().setRandomSeed(10)
        >>> algo.getRandomSeed()
        10
        """
        self._paramMap[self.randomSeed] = value
        return self

    def getRandomSeed(self):
        """
        Gets the value of `randomSeed`
        """
        return self.getOrDefault(self.randomSeed)
    
    def setDataGrowthFactor(self, value):
        """
        Sets the value of :py:attr:`dataGrowthFactor`.

        >>> algo = CADSEstimator().setDataGrowthFactor(1.5)
        >>> algo.getDataGrowthFactor()
        1.5
        """
        self._paramMap[self.dataGrowthFactor] = value
        return self

    def getDataGrowthFactor(self):
        """
        Gets the value of `dataGrowthFactor`
        """
        return self.getOrDefault(self.dataGrowthFactor)

    def setInitialSampleSize(self, value):
        """
        Sets the value of :py:attr:`initialSampleSize`.

        >>> algo = CADSEstimator().setInitialSampleSize(500)
        >>> algo.getInitialSampleSize()
        500
        """
        self._paramMap[self.initialSampleSize] = value
        return self

    def getInitialSampleSize(self):
        """
        Gets the value of `initialSampleSize`
        """
        return self.getOrDefault(self.initialSampleSize)
    
    def setNumSampleFolds(self, value):
        """
        Sets the value of :py:attr:`numSampleFolds`.

        >>> algo = CADSEstimator().setNumSampleFolds(3)
        >>> algo.getNumSampleFolds()
        3
        """
        self._paramMap[self.numSampleFolds] = value
        return self

    def getNumSampleFolds(self):
        """
        Gets the value of `numSampleFolds`
        """
        return self.getOrDefault(self.numSampleFolds)   
    
    
    def setMaxNumPointsForPredictionParam(self, value):
        """
        Sets the value of :py:attr:`maxNumPointsForPredictionParam`.

        >>> algo = CADSEstimator().setMaxNumPointsForPredictionParam(5)
        >>> algo.getNumSampleFolds()
        3
        """
        self._paramMap[self.maxNumPointsForPredictionParam] = value
        return self

    def getMaxNumPointsForPredictionParam(self):
        """
        Gets the value of `maxNumPointsForPredictionParam`
        """
        return self.getOrDefault(self.maxNumPointsForPredictionParam)   
    
    def setKeepBestNLearners(self, value):
        """
        Sets the value of :py:attr:`keepBestNLearners`.

        >>> algo = CADSEstimator().setKeepBestNLearners(3)
        >>> algo.getKeepBestNLearners()
        3
        """
        self._paramMap[self.keepBestNLearners] = value
        return self

    def getKeepBestNLearners(self):
        """
        Gets the value of `keepBestNLearners`
        """
        return self.getOrDefault(self.keepBestNLearners)
    
    def setEvaluator(self, value):
        """
        Sets the value of :py:attr:`evaluator`.

        >>> algo = CADSEstimator().setEvaluator(BinaryClassificationEvaluator().setMetricName("areaUnderROC"))
        
        """
        sEvaluator = None
        if isinstance(value, JavaEvaluator):
            value._transfer_params_to_java()
            sEvaluator = value._java_obj
        else:
            jvmObject = _jvm()
            newEvaluatorProxyObject = jvmObject.com.ibm.analytics.wml.pythonbinding.EvaluatorProxy
            newEvaluatorWrapper = CADSEvaluatorWrapper(value)
            sEvaluator = newEvaluatorProxyObject(newEvaluatorWrapper)

        self._paramMap[self.evaluator] = sEvaluator
        return self
    
    def  _updateDefaultEvaluator(self):
        rowEvaluator = self.getOrDefault(self.evaluator)
        if rowEvaluator is not None:
            self.setEvaluator(rowEvaluator)
            
    def setMaxParallelEstimators(self, value):
        """
        Sets the value of :py:attr:`maxParallelEstimators`.

        >>> algo = CADSEstimator().setMaxParallelEstimators(3)
        >>> algo.getKeepBestNLearners()
        3
        """
        self._paramMap[self.getMaxParallelEstimators] = value
        return self

    def getMaxParallelEstimators(self):
        """
        Gets the value of `keepBestNLearners`
        """
        return self.getOrDefault(self.maxParallelEstimators)
    
    def setTarget(self, value):
        """
        Sets the value of :py:attr:`target`.

        >>> algo = CADSEstimator().setTarget(Target("rawPrediction", "label"))
        >>> algo.getTarget()
        3
        """
        self._paramMap[self.target] = value.to_target_java_object()
        return self
    
    
    def setCombinatorialTransformers(self, value):
        """
        Sets the value of :py:attr:`combinatorialTransformers`.
        >>> algo = CADSEstimator().setCombinatorialTransformers([ TraceDummyTranformer(), TraceDummyTranformer()])
        
        """
        self._combinatorialTransformers = value
        return self
    
    def getCombinatorialTransformers(self):
        return self._combinatorialTransformers
    
    def _updateCustomParams(self):
        sc = SparkContext.getOrCreate()
        jvmObject = _jvm()
        values = self._combinatorialTransformers
        _jToScalaList = jvmObject.com.ibm.analytics.wml.pythonbinding.Helper.javaToScalaList
        pCombinatorialTransformers = [CADSTransformerWrapper(item).to_transformer_java_object()  for item in values]
        jCombinatorialTransformers = ListConverter().convert(pCombinatorialTransformers, sc._gateway._gateway_client)
        sCombinatorialTransformers = _jToScalaList(jCombinatorialTransformers)

        self._paramMap[self.combinatorialTransformers] = sCombinatorialTransformers
        return self

