################################################################################
# IBM Confidential
# OCO Source Materials
# (c) Copyright IBM Corp. 2017
# US Government Users Restricted Rights - Use, duplication disclosure restricted
# by GSA ADP Schedule Contract with IBM Corp.
################################################################################
'''
Created on Jul 15, 2016

@author: calin
'''

import logging
import multiprocessing
from py4j.java_collections import ListConverter
from pyspark import SparkContext
from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pyspark.ml.param import Param, Params
from pyspark import  keyword_only
from pyspark.ml.wrapper import  _jvm
from pyspark.ml.wrapper import JavaEstimator, JavaModel
from pyspark.ml.common import inherit_doc

from cadspy.cadsparam import CadsParams
from cadspy.iterationhook import _IterationProxy


__all__ = ['CADSEstimator', 'CADSModel']

logger = logging.getLogger("ml-algorithms")

@inherit_doc
class CADSEstimator(JavaEstimator, CadsParams):
    """
    CADS Estimator
    produces near optimal model
    """
    
    learners = Param(Params._dummy(), "learners", "List of learners")

    
    @keyword_only
    def __init__(self, randomSeed=1, dataGrowthFactor=1.5, initialSampleSize=500,
                  numSampleFolds=3, maxNumPointsForPrediction=5, keepBestNLearners=3, learners=[], evaluator=None, maxParallelEstimators=multiprocessing.cpu_count(), combinatorialTransformers=[]):

        super(CADSEstimator, self).__init__()   
        self._java_obj = self._new_java_obj("com.ibm.analytics.wml.cads.CADSEstimator", self.uid)
        self.learners = Param(self, "learners", "List of learners")
        self._setDefault(randomSeed=1, dataGrowthFactor=1.5, initialSampleSize=500, numSampleFolds=3, maxNumPointsForPrediction=5, keepBestNLearners=3, learners=[], evaluator=BinaryClassificationEvaluator().setMetricName("areaUnderROC"), maxParallelEstimators=multiprocessing.cpu_count(), combinatorialTransformers=[])
        kwargs = self.__init__._input_kwargs
        self.setParams(**kwargs)
        self._updateDefaultEvaluator()
     
    def _create_model(self, java_model):
        try:
            return CADSModel(java_model)
        except Exception, e:
            logger.exception(e)
            raise
    
    @keyword_only
    def setParams(self, randomSeed=1, dataGrowthFactor=1.5, initialSampleSize=500,
                  numSampleFolds=3,maxNumPointsForPrediction=5, keepBestNLearners=3, learners=[], maxParallelEstimators=multiprocessing.cpu_count(), combinatorialTransformers = []):
        kwargs = self.setParams._input_kwargs
        return self._set(**kwargs)
    
    def _fit_java(self, dataset):
        """
        Fits a Java model to the input dataset.
 
        :param dataset: input dataset, which is an instance of
                        :py:class:`pyspark.sql.DataFrame`
        :param params: additional params (overwriting embedded values)
        :return: fitted Java model
        """
        self._updateCustomParams()
        self._transfer_params_to_java()
        return self._java_obj.fit(dataset._jdf)
    
    def stop(self):
        logger.info("CADS instance was stopped")
        self._java_obj.stop()
        
    def withIterationHook(self, hook):
        _jProxyObj = _jvm().com.ibm.analytics.wml.pythonbinding.IterationProxy
        hookProxy = _IterationProxy(hook)
        
        sHookProxy = _jProxyObj.toIterationHookProxy(hookProxy)
        self._java_obj = self._java_obj.withIterationHook(sHookProxy)
        return self

    def setLearners(self, value):
        """
        Sets the value of :py:attr:`learners`.
        >>> algo = CADSEstimator().setLearners([ Learner("LR", LogisticRegression(maxIter=10, regParam=0.01), )])
        
        """
        
        sc = SparkContext.getOrCreate()
        jvmObject = _jvm()
        _jToScalaList = jvmObject.com.ibm.analytics.wml.pythonbinding.Helper.javaToScalaList
        pLearners = [i.to_learner_java_object() for i in value]
        jLearners = ListConverter().convert(pLearners, sc._gateway._gateway_client)
        sLearners = _jToScalaList(jLearners)

        self._paramMap[self.learners] = sLearners
        return self
    

    
class CADSModel(JavaModel):
    """
    CADS Model 
    """
    learnerName = Param(Params._dummy(), "learners", "List of learners")
     
    def __init__(self, java_model):
        super(CADSModel, self).__init__(java_model)
        self.learnerName = Param(self, "learnerName", "Learner name")
    
    def setLearnerName(self, value):
        """
        Sets the value of :py:attr:`learnerName`.

        >>> algo = CADSModel().setLearnerName("test")
        >>> algo.getLearnerName()
        test
        """
        self._paramMap[self.learnerName] = value
        return self

    def getLearnerName(self):
        """
        Gets the value of `randomSeed`
        """
        return self.getOrDefault(self.learnerName)
   
        
    
    
