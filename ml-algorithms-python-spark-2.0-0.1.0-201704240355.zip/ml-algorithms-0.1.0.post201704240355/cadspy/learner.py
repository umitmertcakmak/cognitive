################################################################################
# IBM Confidential
# OCO Source Materials
# (c) Copyright IBM Corp. 2017
# US Government Users Restricted Rights - Use, duplication disclosure restricted
# by GSA ADP Schedule Contract with IBM Corp.
################################################################################
'''
Created on Jul 15, 2016

@author: calin
'''
import logging
from pyspark import SparkContext, SQLContext
from pyspark.ml.param import Params, Param
from pyspark.ml.pipeline import Estimator, Pipeline
from pyspark.ml.util import Identifiable
from pyspark.ml.wrapper import  _jvm , JavaEstimator
from pyspark.sql import DataFrame


__all__ = ['Learner', 'Target']

logger = logging.getLogger("ml-algorithms")


class Target(object):
    '''
    Target object - tuple of prediction and label field
    '''
    def __init__(self, predictionField, labelField):
        '''
        Constructor for Target field
        '''
        self.predictionField = predictionField
        self.labelField = labelField
     
    def __str__(self):
        return ("Targets: [predictionField=" + self.predictionField + ",labelField=" + self.labelField + "]")
    
    def to_target_java_object(self):
        jvmObject = _jvm()
        newTargetObject = jvmObject.com.ibm.analytics.wml.Target
        return newTargetObject(self.predictionField, self.labelField)
    

class Learner(object):
    '''
    classdocs
    '''
    estimator = Estimator 
    _realEstimator = Estimator

    def __init__(self, name, estimator, scoreTransformer=None):
        '''
        Constructor for Learner object
        '''
        self.name = name
        self.estimator = estimator
        self.scoreTransformer = scoreTransformer
        
    def __str__(self):
        return ("Name: " + self.name
            + "\nEstimator: " + str(self.estimator)
            + "]\nScoreTransformer: " + str(self.scoreTransformer))
        
    def getName(self):
        return str(self.name)
    
    def to_learner_java_object(self):
        jvmObject = _jvm()
        _jHelperObj = jvmObject.com.ibm.analytics.wml.pythonbinding.Helper
        newLearnerObject = jvmObject.com.ibm.analytics.wml.Learner
        newEstimatorProxyObject = jvmObject.com.ibm.analytics.wml.pythonbinding.EstimatorProxy
        newEstimatorWrapper = CADSEstimatorWrapper(self.estimator)
        scalaTransform = _jHelperObj.noneOption()
        
        try:
            if self.scoreTransformer is not None:
                scalaTransform = _jHelperObj.someOption(CADSTransformerWrapper(self.scoreTransformer).to_transformer_java_object())

            scalaEstimatorProxyObject = newEstimatorProxyObject(newEstimatorWrapper)
            return newLearnerObject(self.name, scalaEstimatorProxyObject, scalaTransform)
        except Exception, e:
            logger.exception(e)
            raise
    
    @classmethod
    def _dummy(cls):
        Learner("dummy", None)

class CADSEstimatorWrapper(object):
    '''
    Internal class to keep a Java mapped estimator of Python instance
    '''
    
    def __init__(self, estimator):
        '''
        Constructor for CADSEstimatorWrapper object
        '''
        self._estimator = estimator
        
    def uid(self):
        return self._estimator.uid
    
    def fit(self, jdataFrame):
        sc = SparkContext.getOrCreate()
        ctx = SQLContext.getOrCreate(sc) 
        try:
            dataFrame = DataFrame(jdataFrame, ctx)
            pModel = self._estimator.fit(dataFrame)
            return CADSModelWrapper(pModel)
        except Exception, e:
            logger.exception(e)
            raise         

    def __str__(self):
        return "CADSEstimatorWrapper uid: " + self.uid()
    
    def toString(self):
        return str(self)
    
    def copy(self, extra=None):
        try:
            jvmObject = _jvm()
            extraNew = dict()
            if extra is not None:
                _jHelperObj = jvmObject.com.ibm.analytics.wml.pythonbinding.Helper
                scalaListParamPair = extra.toSeq().toList()
                jListParamPair = _jHelperObj.scalaToJavaList(scalaListParamPair)
                for pair in jListParamPair:
                    try:
                        param = pair.param()
                        jParamName = param.name()
                        jParamUID = param.parent()
                        jParamDoc = param.doc()
                        idfDummy = Identifiable()
                        idfDummy.uid = str(jParamUID)
                        pParam = Param(idfDummy, str(jParamName), str(jParamDoc)) 
                        jValue = pair.value()
                        extraNew[pParam] = jValue
                    except Exception, e:
                        logger.exception(e)
                        raise 
    
    
            
            return CADSEstimatorWrapper(estimatorCopy(self._estimator, jvmObject, extraNew))
        except Exception, ee:
            logger.exception(ee)
            raise

    class Java:
        implements = ['com.ibm.analytics.wml.pythonbinding.PythonEstimator']
  
  
class CADSModelWrapper(object):
    '''
    Internal class to keep a Java mapped model of Python instance
    '''

    def __init__(self, model):
        '''
        Constructor for CADSModelWrapper object
        '''
        self._model = model
        
    def uid(self):
        return self._model.uid
    
    def transform(self, jDataFrame):
        sc = SparkContext.getOrCreate()
        ctx = SQLContext.getOrCreate(sc) 
        try:
            pDataFrame = DataFrame(jDataFrame, ctx)
            pTransfDataFrame = self._model.transform(pDataFrame)
            return pTransfDataFrame._jdf
        except Exception, e:
            logger.exception(e)
            raise         

  
    def transformSchema(self, jStructType):
        logger.warn("Transform Schema call")
        return jStructType
    
    def __str__(self):
        return "CADSModelWrapper uid: " + self.uid()
    
    def toString(self):
        return str(self)

    class Java:
        implements = ['com.ibm.analytics.wml.pythonbinding.PythonModel']
        
        
class CADSTransformerWrapper(object):
    '''
    Internal class to keep a Java mapped transformer of Python instance
    '''

    def __init__(self, transformer):
        '''
        Constructor for CADSTransformerWrapper object
        '''
        self._transformer = transformer
        
    def uid(self):
        return self._transformer.uid
    
    def transform(self, jDataFrame):
        logger.debug("Transform DF")
        sc = SparkContext.getOrCreate()
        ctx = SQLContext.getOrCreate(sc) 
        try:
            pDataFrame = DataFrame(jDataFrame, ctx)
            pTransfDataFrame = self._transformer.transform(pDataFrame)
            return pTransfDataFrame._jdf
        except Exception, e:
            logger.exception(e)
            raise         

  
    def transformSchema(self, jStructType):
        logger.warn("Transform Schema call")
        return jStructType
    
    def __str__(self):
        return "CADSTransformerWrapper uid: " + self.uid()
    
    def toString(self):
        return str(self)
    
    def to_transformer_java_object(self):
        jvmObject = _jvm()
        newTransformerProxyObject = jvmObject.com.ibm.analytics.wml.pythonbinding.TranformationProxy
        return newTransformerProxyObject(self)


    class Java:
        implements = ['com.ibm.analytics.wml.pythonbinding.PythonTransformer']
        
        
class CADSEvaluatorWrapper(object):
    '''
    Internal class to keep a Java mapped evaluator of Python instance
    '''
    
    def __init__(self, evaluator):
        '''
        Constructor for CADSEstimatorWrapper object
        '''
        self._evaluator = evaluator
        
    def uid(self):
        return self._evaluator.uid
    
    def evaluate(self, jdataFrame):
        sc = SparkContext.getOrCreate()
        ctx = SQLContext.getOrCreate(sc) 
        dataFrame = DataFrame(jdataFrame, ctx)
        try:
            evaluationValue = self._evaluator.evaluate(dataFrame)
            return evaluationValue
        except Exception, e:
            logger.exception(e)
            raise         

    def __str__(self):
        return "CADSEvaluatorWrapper uid: " + self.uid()
    
    def toString(self):
        return str(self)

    class Java:
        implements = ['com.ibm.analytics.wml.pythonbinding.PythonEvaluator']
    
def estimatorCopy(estimator, jvmObject, extra=None):
    if extra is None:
        extra = dict()
    if isinstance(estimator , Pipeline):
        that = Params.copy(estimator, extra)
        stages = [estimatorCopy(stage, jvmObject, extra) for stage in that.getStages()]
        return that.setStages(stages)
    elif (isinstance(estimator,JavaEstimator)):
        newJavaEstimator = estimator.copy(extra)
        paramMapConstructor = jvmObject.org.apache.spark.ml.param.ParamMap
        jParamMap = paramMapConstructor()
        newJavaEstimator._java_obj = newJavaEstimator._java_obj.copy(jParamMap)
        return newJavaEstimator
    else :
        return estimator.copy(extra)
