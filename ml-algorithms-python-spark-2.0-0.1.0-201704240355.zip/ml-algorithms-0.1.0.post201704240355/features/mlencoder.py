################################################################################
# IBM Confidential
# OCO Source Materials
# (c) Copyright IBM Corp. 2017
# US Government Users Restricted Rights - Use, duplication disclosure restricted
# by GSA ADP Schedule Contract with IBM Corp.
################################################################################
'''
Created on Dec 16, 2016

@author: calin
'''
from abc import ABCMeta, abstractmethod

from pyspark.ml.common import inherit_doc
from pyspark.ml.param import Params, Param, TypeConverters
from pyspark.ml.wrapper import JavaParams


class MLEncoderParams(Params):
    decodedField = Param(Params._dummy(), "decodedField", "The decoded output field",
                         typeConverter=TypeConverters.toString)
    predictionField = Param(Params._dummy(), "predictionField", "The prediction numeric field that will be decoded",
                            typeConverter=TypeConverters.toString)

    def setDecodedField(self, value):
        """
        Sets the value of :py:attr:`decodedField`.
        """
        return self._set(decodedField=value)

    def getDecodedField(self):
        """
        Gets the value of `decodedField`
        """
        return self.getOrDefault(self.decodedField)

    def setPredictionField(self, value):
        """
        Sets the value of :py:attr:`predictionField`.
        """
        return self._set(predictionField=value)

    def getPredictionField(self):
        """
        Gets the value of `predictionField`
        """
        return self.getOrDefault(self.predictionField)


@inherit_doc
class MLEncoder(MLEncoderParams):
    """
    Abstract class for MLEncoder that provide decoder instances

    """

    __metaclass__ = ABCMeta

    @abstractmethod
    def decoder(self):
        """
        return decoder

        :returns: decoder transformer instance
        """
        raise NotImplementedError()


class JavaMLEncoder(MLEncoder, JavaParams):
    """
    Abstract class for MLEncoder that provide decoder instances

    """

    def decoder(self):
        """
        return decoder
        :returns: decoder transformer instance
        """
        java_decoder = self._decoder_java()
        decoder = self._create_decoder(java_decoder)
        decoder.uid = str(java_decoder.uid())
        return decoder


    def _decoder_java(self):
        """
        Call Decoder fromJava model to the input dataset.

        :return: decoder Java transformer
        """
        self._transfer_params_to_java()
        return self._java_obj.decoder()

    @abstractmethod
    def _create_decoder(self, java_decoder):
        """
        Creates a decoder from the input Java transformer reference.
        """
        raise NotImplementedError()
