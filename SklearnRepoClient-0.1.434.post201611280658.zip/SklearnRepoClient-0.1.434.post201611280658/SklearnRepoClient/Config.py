git = dict(
    host_fvt="https://ibm-watson-ml-fvt.stage1.mybluemix.net",
    host_dev="https://ibm-watson-ml-dev.stage1.mybluemix.net",
    host_prod="https://ibm-watson-ml.stage1.mybluemix.net",
    save="/v1/repos/artifacts",
    load="/v1/repos/artifacts/",
    repo="/v1/repos",
    branch="master",
    message="saving model to git",
    revisionSpec="HEAD"
)

# host_fvt="http://nginx-prim-fvt.spark.bluemix.net:12501"