from setuptools import setup

VERSION='0.1.434-201611280658'
setup(name='SklearnRepoClient',
      version=VERSION,
      description='SklearnRepoClient Library',
      url='https://github.ibm.com/NGP-TWC/platform-pipeline/',
      author='IBM',
      author_email='ibm@ibm.com',
      license='IBM',
      packages=['SklearnRepoClient'],
      zip_safe=False)
