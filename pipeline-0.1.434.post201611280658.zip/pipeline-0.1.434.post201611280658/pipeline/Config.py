git = dict(
    host_fvt="https://ibm-watson-ml-dev.stage1.mybluemix.net",
    host_dev="http://nginx-prim-dev.spark.bluemix.net:12501",
    host_prod="http://nginx-prim-prod.spark.bluemix.net:12501",
    save="/v1/repos/artifacts",
    load="/v1/repos/artifacts",
    repo="/v1/repos",
    branch="master",
    message="saving model to git",
    revisionSpec="HEAD"
)

# host_fvt="http://nginx-prim-fvt.spark.bluemix.net:12501"