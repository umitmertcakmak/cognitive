export JAVA_HOME=/usr/lib/jvm/java
/usr/bin/nohup $JAVA_HOME/bin/java -classpath "/opt/ibm/repo/conf:/opt/ibm/repo/conf/log4j
.propeties:/opt/ibm/repo/lib/*" \
 -Dconfig.file="/opt/ibm/repo/conf/repoService.conf" \
  com.ibm.analytics.ngp.gitrepo.service.JettyServer  \
 > "/opt/ibm/repo/logs/repo-service.log" 2>&1 &
 /bin/echo $! > "/opt/ibm/repo/repo-service-rest.pid"
