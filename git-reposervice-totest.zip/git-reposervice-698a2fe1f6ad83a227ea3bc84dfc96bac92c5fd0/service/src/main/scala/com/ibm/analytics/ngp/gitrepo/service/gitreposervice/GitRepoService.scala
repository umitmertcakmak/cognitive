package com.ibm.analytics.ngp.gitrepo.service.gitreposervice

import java.io.{PrintWriter, StringWriter}
import javax.ws.rs._
import javax.ws.rs.client.{ClientBuilder, Entity, WebTarget}
import javax.ws.rs.core.{MediaType, Response}

import com.ibm.analytics.ngp.gitrepo.service.GitClient
import com.ibm.analytics.ngp.gitrepo.service.logging.UniqueIDGenerator
import com.ibm.analytics.ngp.gitrepo.service.model._
import com.ibm.analytics.ngp.util.Connections
import com.typesafe.config.ConfigFactory
import org.json4s.DefaultFormats
import org.json4s.jackson.JsonMethods._
import org.slf4j.{LoggerFactory, MDC}


@Path("gitClientService")
class GitRepoService {

  @transient
  private lazy val logger = LoggerFactory.getLogger(classOf[GitRepoService])
  private val config = ConfigFactory.load()
  private val refBatchSecret = config.getString("service.deploymentService.secret")
  private val endPointModelMap: Map[String, String] = Map("save" -> "Save", "commitLog" -> "Log",
    "load" -> "Load", "createRepo" -> "CreateRepo", "delete" -> "Delete", "deleteBranch" -> "DeleteBranch",
    "listBranches" -> "ListBranches", "merge" -> "Merge","createRepo"->"CreateRepo")

  private val endPointGitFuncMap: Map[String, String] = Map("save" -> "save", "commitLog" -> "commitLog",
    "load" -> "load", "delete" -> "deleteFile", "deleteBranch" -> "deleteBranch",
    "createBranch" -> "createBranch", "listBranches" -> "listBranches", "mergeBranches" ->
      "merge","createRepo"->"callGitHubRestApi")

  private[this] def setLogRequestId: Unit = {
    val requestId = new UniqueIDGenerator().generateUniqueID("GITREPO")
    MDC.put("RequestID", requestId)
    logger.info(s"RequestID set=$requestId")
  }

  private[this] def execGitFunction(auth: String, batchSecret: String, batchUserId: String, json:
  String, endPointName: String): Response = {

    var repoName: String = ""
    var branchName: String = ""
    var gitPath: String = ""
    var fileContent: String = ""
    var userCommitMessage: String = ""
    var revisionSpec: String = ""
    var fromBranchName: String = ""
    var toBranchName: String = "'"
    val gitFunctionName = endPointGitFuncMap(endPointName)
    var orgName = ""
    logger.info("inside execGitFunction for end point "+endPointName)

    try {

      implicit val formats = DefaultFormats
      val token = Option(auth) match {
        case Some(x) => auth.split("[bB]earer[ ]+").last
        case None => ""
      }

      logger.info(s"Token received from the ${endPointName} request: ${token}")

      val toValidateToken = isInvalidBatchSecret(batchSecret)
      val userId = toValidateToken match {
        case true => {
          token match {
            case "" => ""
            case _ => getUserIdFromToken(token)
          }
        }
        case false =>  Option(batchUserId) match { case None => ""
        case Some(s)=>s
                 }
      }

      if (userId.equals("")) throw new IllegalArgumentException("Both Token & Batch Secret Cannot Be Invalid")

      logger.info(s"User Calling gitClient.save() = ${userId}")

      endPointName match {
        case "save" => {
          val requestBody = parse(json).extract[Save]
          repoName = requestBody.repoName
          branchName = requestBody.branchName
          gitPath = requestBody.gitPath
          fileContent = requestBody.fileContent
          userCommitMessage = requestBody.userCommitMessage
        }
        case "load" => {
          val requestBody = parse(json).extract[Load]
          repoName = requestBody.repoName
          branchName = requestBody.branchName
          gitPath = requestBody.gitPath
          revisionSpec = requestBody.revisionSpec
        }
        case "commitLog" => {
          val requestBody = parse(json).extract[Log]
          repoName = requestBody.repoName
          branchName = requestBody.branchName
          gitPath = requestBody.gitPath
        }

        case "delete" => {
          val requestBody = parse(json).extract[Delete]
          repoName = requestBody.repoName
          branchName = requestBody.branchName
          gitPath = requestBody.gitPath
          userCommitMessage = requestBody.commitMessage
        }
        case "lsitBranches" => {
          val requestBody = parse(json).extract[ListBranches]
          repoName = requestBody.repoName
          branchName = "master"
        }
        case "mergeBranches" => {
          val requestBody = parse(json).extract[Merge]
          repoName = requestBody.repoName
          fromBranchName = requestBody.fromBranchName
          toBranchName = requestBody.toBranchName
        }
        case "createBranch" => {
          val requestBody = parse(json).extract[CreateBranch]
          repoName = requestBody.repoName
          branchName = requestBody.branchName
          userCommitMessage = requestBody.commitMessage
        }
        case "createRepo" => {
          val requestBody = parse(json).extract[CreateRepo]
          repoName = requestBody.repoName
          orgName = requestBody.orgName
        }
      }
      if (!gitFunctionName.equals("callGitHubRestApi")) {
        logger.info(s"Going to Call gitClient ${gitFunctionName}() on gitPath = ${gitPath} in " +
          s"Repository = ${repoName} in the branch = ${branchName}")
        val gc: GitClient = GitClient(repoName, branchName, userId)
        gc.intialize
        val entity = endPointName match {
          case "save" => gc.save(repoName, gitPath, fileContent, userCommitMessage, userId)
          case "load" => gc.load(repoName, revisionSpec, gitPath)
          case "commitLog" => gc.commitLog(repoName, gitPath)
          case "delete" => gc.deleteFile(repoName, branchName, gitPath, userId, userCommitMessage)
          case "listBranches" => gc.listBranches(repoName, branchName)
          case "mergeBranches" => gc.merge(fromBranchName, toBranchName, userId, userCommitMessage)
          case "createBranch" => gc.createBranch(repoName, branchName, userId, userCommitMessage)
        }
        gc.unInitialize
      //  logger.info("entiry from end point "+endPointName+":"+entity)
        Response.ok(entity, MediaType.TEXT_PLAIN).build()
      }
      else
        {
          val entity = endPointName match {
            case "createRepo" => {
              val gitHubCreateRepoApiEndPoint = "/orgs/" + orgName + "/repos"
              val clientRequestBody: String = s"""{"name":""" + "\"" + repoName + "\"" +
                "," + "\"private\":false,\"auto_init\":true}"
               val response=callGitHubRestApi(gitHubCreateRepoApiEndPoint, clientRequestBody)
            }
          }
          Response.ok(entity, MediaType.TEXT_PLAIN).build()
      }
    } catch {
      case e: Exception => {
        logger.error(s"Exception in ${gitFunctionName}() request : ${e.getMessage}")
        e.printStackTrace()
        Response.serverError().entity(e.getMessage).build()
      }
    }
  }

  private[this] def getUserIdFromToken(token: String): String = {
    try {
      val sub = Connections.getSubFromIdaas(token)
      val userId = Connections.getIuiFromAccounts(sub, token)
      userId
    } catch {
      case e: Exception =>
        val msg = s"Exception while validating token ${getStackTrace(e)}"
        logger.error(msg)
        throw new Exception(msg)
    }
  }

  private[this] def getStackTrace(e: Throwable): String = {
    val sw = new StringWriter()
    e.printStackTrace(new PrintWriter(sw))
    sw.toString()
  }

  private[this] def isInvalidBatchSecret(batchSecret: String) = {
    Option(batchSecret) match {
      case Some(x) => x match {
        case "" => true
        case _ => !x.equals(refBatchSecret)
      }
      case None => true
    }
  }

  def callGitHubRestApi(githubApiEndPoint: String, requestBody: String): Response = {
    try {
      val githubToken = config.getString("service.git.github.githubToken")
      val githubEndPoint = config.getString("service.git.github.gitHubApiEndPoint")
      val githubApiEndPointUrl = githubEndPoint + githubApiEndPoint
      logger.info("github end point " + githubEndPoint)
      logger.info("requesBody=" + requestBody)
      //  val client:com.sun.jersey.api.client.Client = com.sun.jersey.api.client.Client.create()
      // val webResource:com.sun.jersey.api.client.WebResource = client.resource(gitHubCreateRepoEndPoint)
      // val clientResponse:com.sun.jersey.api.client.ClientResponse =
      val client: javax.ws.rs.client.Client = ClientBuilder.newClient()
      val target: WebTarget = client.target(githubApiEndPointUrl)
      val response: Response = target.request().header("Authorization", "token " + githubToken)
        .accept(MediaType.APPLICATION_JSON).post(Entity.json(requestBody), classOf[Response])
      /*val response=  webResource.accept("application/json")
       .header("Content-type", "application/json")
       .header("Authorization","token "+githubToken)
       .post(classOf[ClientResponse],clientRequestBody).asInstanceOf[ClientResponse]
       */
      if (response.getStatus == 201) {
        logger.info("inside 201")
        javax.ws.rs.core.Response.ok(response.getEntity).build()
      }
      else
        throw new Exception("Error whle calling api " + githubApiEndPointUrl + ", status code=" +
          response.getStatus + "\n error message: " + response)
    } catch {
      case e: Exception => {
        logger.error("Exception while creating  repo" + e.fillInStackTrace.toString)
        throw e
        //return javax.ws.rs.core.Response.serverError().entity(e.fillInStackTrace.toString).build()
      }
    }
  }

  @POST
  @Path("save")
  @Consumes(Array(MediaType.APPLICATION_JSON))
  @Produces(Array(MediaType.TEXT_PLAIN))
  def save(@HeaderParam("Authorization") auth: String,
           @HeaderParam("Batch-Secret") batchSecret: String,
           @HeaderParam("UserId") batchUserId: String,
           json: String): Response = {
    setLogRequestId
    logger.debug("Starting save() request")
    execGitFunction(auth, batchSecret, batchUserId, json, "save")

  }

  @POST
  @Path("load")
  @Consumes(Array(MediaType.APPLICATION_JSON))
  @Produces(Array(MediaType.TEXT_PLAIN))
  def load(@HeaderParam("Authorization") auth: String,
           @HeaderParam("Batch-Secret") batchSecret: String,
           @HeaderParam("UserId") batchUserId: String,
           json: String): Response = {
    setLogRequestId
    logger.debug("Starting load() request , request json below \n"+json)
    val resp:Response=execGitFunction(auth, batchSecret, batchUserId, json, "load")
     logger.info("entiry from load call:"+resp.getEntity.toString)
    resp
  }

  @POST
  @Path("commitLog")
  @Consumes(Array(MediaType.APPLICATION_JSON))
  @Produces(Array(MediaType.TEXT_PLAIN))
  def commitLog(@HeaderParam("Authorization") auth: String,
                @HeaderParam("Batch-Secret") batchSecret: String,
                @HeaderParam("UserId") batchUserId: String,
                json: String): Response = {
    setLogRequestId
    logger.debug("Starting commitLog() request")
    execGitFunction(auth, batchSecret, batchUserId, json, "commitLog")
  }

  @POST
  @Path("delete")
  @Consumes(Array(MediaType.APPLICATION_JSON))
  @Produces(Array(MediaType.TEXT_PLAIN))
  def delete(@HeaderParam("Authorization") auth: String,
             @HeaderParam("Batch-Secret") batchSecret: String,
             @HeaderParam("UserId") batchUserId: String,
             json: String): Response = {
    setLogRequestId
    logger.debug("Starting commitLog() request")
    execGitFunction(auth, batchSecret, batchUserId, json, "delete")
  }

  @POST
  @Path("createBranch")
  @Consumes(Array(MediaType.APPLICATION_JSON))
  @Produces(Array(MediaType.TEXT_PLAIN))
  def listBranches(@HeaderParam("Authorization") auth: String,
                   @HeaderParam("Batch-Secret") batchSecret: String,
                   @HeaderParam("UserId") batchUserId: String,
                   json: String): Response = {
    setLogRequestId
    logger.debug("Starting commitLog() request")
    execGitFunction(auth, batchSecret, batchUserId, json, "createBranch")
  }

  @POST
  @Path("listBranches")
  @Consumes(Array(MediaType.APPLICATION_JSON))
  @Produces(Array(MediaType.TEXT_PLAIN))
  def createBranch(@HeaderParam("Authorization") auth: String,
                   @HeaderParam("Batch-Secret") batchSecret: String,
                   @HeaderParam("UserId") batchUserId: String,
                   json: String): Response = {
    setLogRequestId
    logger.debug("Starting listBranches() request")
    execGitFunction(auth, batchSecret, batchUserId, json, "listBranches")
  }

  @POST
  @Path("mergeBranches")
  @Consumes(Array(MediaType.APPLICATION_JSON))
  @Produces(Array(MediaType.TEXT_PLAIN))
  def mergeBranches(@HeaderParam("Authorization") auth: String,
                    @HeaderParam("Batch-Secret") batchSecret: String,
                    @HeaderParam("UserId") batchUserId: String,
                    json: String): Response = {
    setLogRequestId
    logger.debug("Starting merge() request")
    execGitFunction(auth, batchSecret, batchUserId, json, "mergeBranches")
  }

  @POST
  @Path("createRepo")
  @Consumes(Array(MediaType.APPLICATION_JSON))
  @Produces(Array(MediaType.TEXT_PLAIN))
  def createGitRepo(@HeaderParam("Authorization") auth: String,
                    @HeaderParam("Batch-Secret") batchSecret: String,
                    @HeaderParam("UserId") batchUserId: String,
                    json: String) = {
    setLogRequestId
    logger.info("Starting cerateRepo() request")
    execGitFunction(auth, batchSecret, batchUserId, json, "createRepo")
  }
}







