package com.ibm.analytics.ngp.gitrepo.service

import com.jcraft.jsch.{JSch, JSchException, _}
import org.eclipse.jgit.transport.{JschConfigSessionFactory, OpenSshConfig}
import org.eclipse.jgit.util.FS
import org.slf4j.LoggerFactory

class CustomJschConfigSessionFactory extends JschConfigSessionFactory {
  @transient
  private lazy val logger = LoggerFactory.getLogger(classOf[CustomJschConfigSessionFactory])

  protected def configure(host: OpenSshConfig.Host, session: Session) {
    logger.debug(s"Setting Up StrictHostKeyChecking :${GitConfig.getStrictHostKeyChecking}")
    session.setConfig("StrictHostKeyChecking", GitConfig.getStrictHostKeyChecking)
  }

  @throws(classOf[JSchException])
  protected override def getJSch(hc: OpenSshConfig.Host, fs: FS): JSch = {
    logger.debug(s"Creating JSch Object with SSH Conig ${hc.toString} for GIT FS ${fs.toString}")
    val jsch: JSch = super.getJSch(hc, fs)
    jsch.removeAllIdentity()
    jsch.addIdentity(GitConfig.getsshIdentity)
    jsch.setKnownHosts(GitConfig.getKnownHosts)
    //jsch.setConfig("PreferredAuthentications", gitConf.getPreferredAuthentications)
    jsch
  }
}


