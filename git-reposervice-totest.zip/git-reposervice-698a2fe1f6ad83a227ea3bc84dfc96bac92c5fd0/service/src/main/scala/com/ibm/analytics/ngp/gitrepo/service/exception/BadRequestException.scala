package com.ibm.analytics.ngp.gitrepo.service.exception

class BadRequestException(msg: String = null, cause: Throwable = null)extends java.lang.Exception(msg, cause) {}