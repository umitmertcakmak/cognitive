package com.ibm.analytics.ngp.gitrepo.service.exception

class MergeConflictsException(msg: String = null, cause: Throwable = null) extends java.lang.Exception(msg, cause) {}

