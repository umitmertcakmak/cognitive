package com.ibm.analytics.ngp.gitrepo.service

import com.ibm.analytics.ngp.gitrepo.service.gitreposervice.GitRepoService
import com.typesafe.config.ConfigFactory
import org.eclipse.jetty.server.Server
import org.eclipse.jetty.servlet.ServletContextHandler

object JettyServer {
  def main(args: Array[String]) {
    val context = new ServletContextHandler(ServletContextHandler.SESSIONS)
    context.setContextPath("/")

    val jettyServer = new Server(8080)
    jettyServer.setHandler(context)

    val jerseyServlet = context.addServlet(
      classOf[org.glassfish.jersey.servlet.ServletContainer], "/*")

    jerseyServlet.setInitOrder(0)
    jerseyServlet.setInitParameter(
      "jersey.config.server.provider.classnames", classOf[GitRepoService].getCanonicalName)

    try {
      //Initialize Git Config Properties.
      val configFile = ConfigFactory.load.getString("service.git.configLocation")
      if(!GitConfig.isInitialized) GitConfig.initialize(configFile)
      // Start jetty server
      jettyServer.getAttributeNames.toString
      jettyServer.start()
      jettyServer.join()

    } finally {
      jettyServer.destroy()
      if(GitConfig.isInitialized) GitConfig.unInitialize()
    }
  }
}



