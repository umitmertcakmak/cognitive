package com.ibm.analytics.ngp.gitrepo.service.logging

import java.security.MessageDigest

import scala.util.Random

/**
 * Created by Srijak Bhaumik on 26/04/16.
 * This class is responsible for methods that will create an
 * Unique ID for every request relieved, based on the Request
 * JSON passed to it.
 */
class UniqueIDGenerator {

  /**
   * Function generateUniqueID(String)
   * input: JSON String
   * Output: Unique ID for every Message
   *
   * Desc: We are using SHA-1 Algorithm to produce an unique Message Digest out of the
   * Request JSON, That will be carried forward for every execution of the Request
   */
  def generateUniqueID(input: String): String = {

    val baseInput = input + getNextSalt() // Base Input String Where Salt will Be Added
    var hexString: String = "" // Hex String For Computing Hash
    var myRequestId: String = "" // Final String for Calculating ID of length 20
    var looper = 0 // Loop Counter Used all Over This Function

    // Initialize the Digest, We choose SHA-1 Algorithm
    val md: MessageDigest = MessageDigest.getInstance("SHA-1")
    val buffer: Array[Byte] = baseInput.getBytes("UTF-8")
    md.reset()
    md.update(buffer)

    // Create The Digest for the message
    val digest: Array[Byte] = md.digest()

    // Create the Unique Id with SHA-1 Algo
    while (looper < digest.length) {
      hexString += Integer.toString((digest(looper) & 0xff) + 0x100, 16).substring(1)
      looper += 1
    }

    looper = 0 // Re-initialize for reducing the ID

    // Reduce the ID to half
    while (looper < hexString.length) {
      if (looper % 2 == 1)
        myRequestId += hexString.charAt(looper)

      looper += 1
    }

    return myRequestId
  }

  /**
   * Function getNextSalt()
   * Input: None
   * output: Random 10 Char String as a Salt
   * Desc: This method returns a random 10 length String every time called.
   * It can be used as a generator of Salt
   */
  def getNextSalt(): String = {
    var mySalt: String = ""
    var i = 0;

    // Generate 10 length Random String
    while (i < 10) {
      mySalt += Random.nextPrintableChar()
      i += 1
    }

    return mySalt
  }
}
