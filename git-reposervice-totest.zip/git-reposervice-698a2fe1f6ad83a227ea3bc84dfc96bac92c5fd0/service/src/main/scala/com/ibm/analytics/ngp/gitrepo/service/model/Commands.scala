package com.ibm.analytics.ngp.gitrepo.service.model

case class Pull(repoName: String, branchName: String)

case class Add(repoName: String, branchName: String, gitPath: String)

case class Update(repoName: String, branchName: String, gitPath: String, fileContent: java.io.InputStream, userCommitMessage: String)

case class Save(repoName: String, branchName: String, gitPath: String, fileContent: String, userCommitMessage: String)

case class Load(repoName: String, branchName: String, revisionSpec: String, gitPath: String)

case class Log(repoName: String, branchName: String, gitPath: String)

case class Delete(repoName: String, branchName: String, gitPath: String, commitMessage: String)

case class ListBranches(repoName: String)

case class CreateBranch(repoName: String, branchName: String, commitMessage: String)

case class DeleteBranch(repoName: String, branchName: String, forceDelete: Boolean, commitMessage: String)

case class Merge(repoName: String, fromBranchName: String, toBranchName: String, commitMessage: String)

case class CreateRepo(orgName: String, repoName: String)




