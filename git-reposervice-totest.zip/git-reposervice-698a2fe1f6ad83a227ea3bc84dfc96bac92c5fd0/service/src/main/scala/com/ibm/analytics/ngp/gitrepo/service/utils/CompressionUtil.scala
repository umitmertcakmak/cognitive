package com.ibm.analytics.ngp.gitrepo.service.utils

import java.io._
import java.util.zip.{GZIPInputStream, GZIPOutputStream}

import org.apache.commons.compress.archivers.tar.{TarArchiveEntry, TarArchiveInputStream, TarArchiveOutputStream}
import org.apache.commons.compress.utils.IOUtils
import org.slf4j.LoggerFactory

import scala.util.control.Breaks._

class CompressionUtil {

  @transient
  private lazy val logger = LoggerFactory.getLogger(classOf[CompressionUtil])

  @throws(classOf[IOException])
  @throws(classOf[FileNotFoundException])
  @throws(classOf[Exception])
  private[this] def createTar(directory: String, filename: String, absolute: Boolean): Boolean = {
    logger.info(s"Creating Tar File ${filename} on directory ${directory}")
    var taos: TarArchiveOutputStream = null
    try {
      val rootDir = new File(directory)
      val saveFile = new File(filename)
      taos = new TarArchiveOutputStream(new FileOutputStream(saveFile))
      taos.setLongFileMode(TarArchiveOutputStream.LONGFILE_GNU)
      recurseFiles(rootDir, rootDir, taos, absolute)
      taos.finish()
      taos.flush()
      taos.close()
      true
    } catch {
      case e: FileNotFoundException => {
        logger.error(s"Error Creating Tar file ${e.getMessage}")
        throw e
      }
      case e: IOException => {
        logger.error(s"Error Creating Tar file ${e.getMessage}")
        try {
          if (taos != null) taos.close()
        } catch {
          case e: IOException => //do nothing
        }
        throw e
      }
      case e: Exception => {
        logger.error(s"Error Creating Tar file ${e.getMessage}")
        throw e
      }
    }
  }

  private[this] def getFileName(root: File, file: File, absolute: Boolean): String = {
    if (absolute) {
      if (root.getAbsolutePath.equals(file.getAbsolutePath))
        file.getAbsolutePath.substring(file.getAbsolutePath.lastIndexOf("/") + 1)
      else
        file.getAbsolutePath.substring(root.getAbsolutePath.length)
    }
    else
    file.getName
  }

  @throws(classOf[IOException])
  private[this] def recurseFiles(root: File, file: File, taos: TarArchiveOutputStream, absolute: Boolean): Unit = {
    logger.debug(s"Recursive File Globbing Function, root : ${root.getName} file : ${file.getName}")
    if (file.isDirectory) {
      val files: Array[File] = file.listFiles
      for (file2 <- files) {
        recurseFiles(root, file2, taos, absolute)
      }
      return
    }
    val fileName = getFileName(root, file, absolute)
    val tae: TarArchiveEntry = new TarArchiveEntry(fileName)
    logger.debug(s"Creating a Tape Archive Entry : ${fileName}")
    tae.setSize(file.length)
    tae.setName(fileName)
    taos.putArchiveEntry(tae)
    val fis: FileInputStream = new FileInputStream(file)
    logger.debug(s"Adding file contents for File : ${fileName}")
    IOUtils.copy(fis, taos)
    taos.closeArchiveEntry()
  }

  @throws(classOf[IOException])
  @throws(classOf[FileNotFoundException])
  @throws(classOf[Exception])
  private[this] def gzip(path: String): Unit = {
    logger.info(s"Gzipping Path (or) File : ${path}")
    var in: BufferedInputStream = null
    var out: GZIPOutputStream = null
    try {

      val buf = new Array[Byte](2048)
      val src = new File(path)
      val dst = new File(path + ".gz")
      in = new BufferedInputStream(new FileInputStream(src))
      out = new GZIPOutputStream(new FileOutputStream(dst))
      var n: Int = in.read(buf)
      while (n >= 0) {
        out.write(buf, 0, n)
        n = in.read(buf)
      }
      out.flush()
      out.close()
      in.close()
    }
    catch {
      case e: FileNotFoundException => {
        logger.error(s"Error Creating Gzip file ${e.getMessage}")
        throw e
      }
      case e: IOException => {
        try {
          if (in != null) in.close()
          if (out != null) out.close()
        } catch {
          case e: IOException => // do nothing
        }
        logger.error(s"Error Creating Gzip file ${e.getMessage}")
        throw e
      }
      case e: Exception => {
        logger.error(s"Error Creating Gzip file ${e.getMessage}")
        throw e
      }
    }
  }

  @throws(classOf[IOException])
  @throws(classOf[FileNotFoundException])
  @throws(classOf[Exception])
  private[this] def gunzip(compressedFile: String, decompressedFile: String): Unit = {
    logger.info(s"Extracting Gzip File : ${compressedFile} to Path (or) File ${decompressedFile}")
    var in: GZIPInputStream = null
    var out: FileOutputStream = null
    try {
      val buf = new Array[Byte](2048)
      in = new GZIPInputStream(new FileInputStream(compressedFile))
      out = new FileOutputStream(decompressedFile)
      var bytes_read: Int = 0
      while ( {
        bytes_read = in.read(buf)
        bytes_read
      } > 0) {
        out.write(buf, 0, bytes_read)
      }
    }
    catch {
      case e: FileNotFoundException => {
        logger.error(s"Error Extracting Gzip file ${e.getMessage}")
        throw e
      }
      case e: IOException => {
        try {
          if (in != null) in.close()
          if (out != null) out.close()
        } catch {
          case e: IOException => // do nothing
        }
        logger.error(s"Error Extracting Gzip file ${e.getMessage}")
        throw e
      }
      case e: Exception => {
        logger.error(s"Error Extracting Gzip file ${e.getMessage}")
        throw e
      }
    }
  }

  //noinspection ComparingUnrelatedTypes
  @throws(classOf[IOException])
  @throws(classOf[FileNotFoundException])
  @throws(classOf[Exception])
  private[this] def extractTar(tarFile: String, directory: String): Unit = {
    logger.info(s"Extracting Tar File : ${tarFile} to Path (or) File ${directory}")
    val tarFileObj = new File(tarFile)
    val directoryFileObj = new File(directory)
    var in: TarArchiveInputStream = null

    try {
      in = new TarArchiveInputStream(new FileInputStream(tarFileObj))
      var entry: TarArchiveEntry = null
      while ({
        entry = in.getNextTarEntry
        entry
        } != null) {
        breakable {
          if (entry.isDirectory)
            break
          val curFile = new File(directoryFileObj, entry.getName)
          val parent: File = curFile.getParentFile
          logger.debug(" extracting  directory= " + directory + " and file=" + entry.getName )
           try {
             if (!parent.exists)
               parent.mkdirs
           } catch {
             case e:Exception=> logger.error("Erorr while creating directory "+parent.getAbsolutePath)
               throw e
           }
          val out = new FileOutputStream(curFile)
         // logger.debug("after FileOutputStream")
          logger.debug(s"Extracting File : ${curFile} from Tar File ${tarFile}")
          try {
            IOUtils.copy(in, out)
            out.close()
          } catch {
            case e: IOException => {
              try {
                if (out != null) out.close()
              } catch {
                case e: IOException => //do nothing
              }
              logger.error(s"Error Writing Tar file contents ${curFile} - ${e.getMessage}")
              throw e;
            }
          }
        }
      }
      in.close()
    } catch {
      case e: FileNotFoundException => {
        logger.error(s"Error Extracting Tar file ${e.getMessage}")
        throw e
      }
      case e: IOException => {
        try {
          if (in != null) in.close()
        } catch {
          case e: IOException => // do nothing
        }
        logger.error(s"Error Extracting Tar file ${e.getMessage}")
        throw e
      }
      case e: Exception => {
        logger.error(s"Error Extracting Tar file ${e.getMessage}")
        throw e
      }
    }
  }

  @throws(classOf[FileNotFoundException])
  @throws(classOf[IOException])
  def delete(path: String): Unit = {
    delete(new File(path))
  }

  @throws(classOf[FileNotFoundException])
  @throws(classOf[IOException])
  def delete(file: File): Unit = {
    logger.info(s"Deleting File : ${file.getName}")
    file.exists match {
      case true => {
        file.isDirectory match {
          case true => org.apache.commons.io.FileUtils.deleteDirectory(file)
          case false => file.delete
        }
      }
      case false => {
        val msg = s"Trying to Delete File : ${file.getName}, it doesn't Exist"
        logger.error(msg)
        throw new FileNotFoundException(msg)
      }
    }
  }

  def unCompressTarFile(localRepoPath:String, filePath :String) : Unit = {
    logger.info(s"UnCompressing file ${localRepoPath}/${filePath}")
    val compressedPath = localRepoPath + "/" + filePath
    val tarFile = compressedPath.replace(".gz","")
    val uncompressedDir = compressedPath.substring(0,compressedPath.lastIndexOf("/"))
    this.gunzip(compressedPath,tarFile)
    this.extractTar(tarFile, uncompressedDir)
    this.delete(tarFile)
    this.delete(compressedPath)
  }

  def generateCompressedFile(localRepoPath:String, dirPath:String) : String = {
    logger.info(s"Generate Compressed File from Directory ${localRepoPath}/${dirPath}")
    val currTime = System.currentTimeMillis()
    val tarFile = s"/tmp/${dirPath}_${currTime}.tar"
    val myFile=new File(tarFile)
    val tarDir=myFile.getParent
    val myDir=new File(tarDir)
    if (!myDir.exists)
      myDir.mkdirs()
    this.createTar(localRepoPath + "/" + dirPath, tarFile, true)
    this.gzip(tarFile)
    this.delete(tarFile)
    tarFile+".gz"
  }
}

object CompressionUtil{
  def apply() = new CompressionUtil()
}




