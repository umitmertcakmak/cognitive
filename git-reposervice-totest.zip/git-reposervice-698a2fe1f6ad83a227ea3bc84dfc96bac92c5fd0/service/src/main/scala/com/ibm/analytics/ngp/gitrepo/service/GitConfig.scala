

package com.ibm.analytics.ngp.gitrepo.service

import java.io._
import java.util.PropertyResourceBundle

import org.slf4j.LoggerFactory
// Loads git configuration set in gitClient.propertes file
// gitClient.propertes file path should be configured in config file
object GitConfig {

  @transient
  private lazy val logger = LoggerFactory.getLogger(GitConfig.getClass)
  //LocalRepo base path
  private[this] var localRepository = "/gitrepo"
  private[this] var StrictHostKeyChecking = "No"
  private[this] var sshIdentity = "/home/ngpuser/.ssh/id_rsa"
  private[this] var knownHosts = "/home/ngpuser/.ssh/known_hosts"
  private[this] var PreferredAuthentications = "publickey"
  //git ssh base url
  private[this] var remoteHost ="git@github.ibm.com"
  //Organization name
  private[this] var remoteRepoPath ="analytic-artifacts"
  var isInitialized = false

  def initialize(configFile: String) = loadConfig(configFile)
  def unInitialize() = {}
  def getlocalRepository = this.localRepository
  def getStrictHostKeyChecking = this.StrictHostKeyChecking
  def getsshIdentity = this.sshIdentity
  def getKnownHosts = this.knownHosts
  def getPreferredAuthentications = this.PreferredAuthentications
  def getRemoteHost = this.remoteHost
  def getRemoteRepoPath = this.remoteRepoPath

  private[this] def loadConfig(configFile: String) {
    var prb: PropertyResourceBundle = null
    try {
      logger.info(s"Loading Git Config Properties from Config File ${configFile}")
      val fis: FileInputStream = new FileInputStream(configFile)
      prb = new PropertyResourceBundle(fis)
    }
    catch {
      case e: FileNotFoundException => {
        logger.error(s"No Properties Config File ${configFile} Found")
        throw e
      }
      case e: IOException => {
        logger.error(s"Error Reading Git Config Properties from Config File ${configFile} -- ${e.getMessage}")
        throw e
      }
    }
    this.localRepository = prb.getString("localRepository")
    this.StrictHostKeyChecking = prb.getString("StrictHostKeyChecking")
    this.sshIdentity = prb.getString("sshIdentity")
    this.knownHosts = prb.getString("knownHosts")
    this.PreferredAuthentications = prb.getString("PreferredAuthentications")
    this.remoteHost=prb.getString("gitRemoteHost")
    this.remoteRepoPath=prb.getString("gitRemoteRepoPath")
    isInitialized = true
  }
}
