package com.ibm.analytics.ngp.gitrepo.service

import java.io._
import java.util
import java.util.Base64

import com.ibm.analytics.ngp.gitrepo.service.exception.MergeConflictsException
import com.ibm.analytics.ngp.gitrepo.service.utils._
import com.jcraft.jsch.JSch
import org.eclipse.jgit.api.CreateBranchCommand.SetupUpstreamMode
import org.eclipse.jgit.api._
import org.eclipse.jgit.api.errors.{GitAPIException, JGitInternalException, NoFilepatternException, RefAlreadyExistsException}
import org.eclipse.jgit.internal.storage.file.FileRepository
import org.eclipse.jgit.lib._
import org.eclipse.jgit.revwalk.{RevCommit, RevTree, RevWalk}
import org.eclipse.jgit.storage.file.FileRepositoryBuilder
import org.eclipse.jgit.transport.{PushResult, RefSpec, SshSessionFactory}
import org.eclipse.jgit.treewalk.TreeWalk
import org.slf4j.LoggerFactory

import scala.collection.JavaConversions._

object GitClient {
  def apply(repoName: String, branchName: String, userId: String): GitClient = new GitClient(repoName, branchName, userId)
}

class GitClient(repoName: String, branchName: String, userId: String) {

  @transient
  private lazy val logger = LoggerFactory.getLogger(classOf[GitClient])
  private[this] val compressionUtil = CompressionUtil()
  //Directory in local host where local repository sits
  private[this] var localPath = GitConfig.getlocalRepository + this.userId + "/" + this.repoName
  //git ssh url for the repo
  private[this] var remotePath = GitConfig.getRemoteHost + ":" + GitConfig.getRemoteRepoPath + "/" + this.repoName + ".git"
  //absolute path for local .git file of repo
  private[this] var localRepo: Repository = new FileRepository(this.localPath + "/.git")
  private[this] var git = new Git(this.localRepo)
  private[this] var jschConfigSessionFactory: CustomJschConfigSessionFactory = new CustomJschConfigSessionFactory()
  private[this] var jsch: JSch = new JSch
// initialize git with repoName,branchName and commiterId
  def intialize: Unit = {
    logger.info(s"Initializing Git Client for Repository ${this.repoName}/${this.branchName} for User : ${this.userId}")
    SshSessionFactory.setInstance(this.jschConfigSessionFactory)
    this.pull(this.repoName)
  }

  def unInitialize: Unit = {}

  @throws(classOf[IOException])
  @throws(classOf[GitAPIException])
  def createRepo(dirPath: String): Unit = {
    logger.info(s"Creating Repository in the Path: $dirPath")
    val builder: FileRepositoryBuilder = new FileRepositoryBuilder
    val repoDir: File = new File(dirPath)
    val newRepo: Repository = builder.setGitDir(repoDir).build
    newRepo.create(true)
  }
//Function for cloning repo , it is called from pull if local repo does not exist
  @throws(classOf[Exception])
  def cloneRepo(repoName: String): Unit = {
    logger.info(s"Cloning Repository in the Path: $repoName")
    try {
      if (localRepo.getDirectory == null || !new File(localPath + "/.git").exists) {
        val clncmd: CloneCommand = Git.cloneRepository
        clncmd.setURI(remotePath)
        clncmd.setDirectory(new File(localPath))
        clncmd.call
      }
      else {
        this.pull(repoName)
      }
    } catch {
      case e: Exception =>
        if (new File(localPath).exists) {
          logger.info("In Exception Handling,Deleting the errorly cloned repo${localPath}")
          //TODO: Do we really need to delete the repo ? Analyze
          compressionUtil.delete(localPath)
        }
        logger.error(s"Error while cloning repo ${e.getMessage}")
        throw e
    }
  }
// function for git pull , pull is called in each call
  @throws(classOf[IOException])
  @throws(classOf[GitAPIException])
  def pull(repoName: String): Unit = {
    logger.info(s"Running Pull on the Repository : ${repoName}")
    try {
      if (localRepo.getDirectory == null || !new File(localPath + "/.git").exists) this.cloneRepo(repoName)
      val pr: PullResult = this.git.pull.call
      if (!pr.isSuccessful) {
        if (!pr.getMergeResult.getMergeStatus.isSuccessful) {
          var conflicts: String = ""
          pr.getMergeResult.getConflicts.keySet.foreach(s => conflicts = conflicts + "\n" + s)
          throw new MergeConflictsException(s"Merge Conflicts in Pull Request on Repository ${repoName} -- ${conflicts}")
        }
        else {
          throw new Exception(s"Pull Request Failed on Repository ${repoName}")
        }
      }
    } catch {
      case e: Exception => {
        logger.error(e.getMessage)
        throw e
      }
    }
  }
// add function  for adding file or directory
  @throws(classOf[IOException])
  @throws(classOf[GitAPIException])
  def add(repoName: String, filePath: String) = {
    logger.info(s"Adding File to Repository ${repoName} -- ${filePath}")
    this.git.checkout().setName(this.branchName).call
    val myfile = new File(localPath + "/" + filePath)
    if (!myfile.exists) {
      logger.debug("File Path Does not exist, Creating File " + localPath + "/" + filePath)
      val dirName = myfile.getParent;
      if (!(dirName.equals("") || dirName == null)) {
        val mydir = new File(dirName)
        if (!mydir.exists)
          try {
            mydir.mkdirs
          } catch {
            case e: Exception => {
              logger.error("Exception while Creating Directory " + dirName)
            }
          }
      }
      myfile.createNewFile
    }
    logger.debug(s"Adding file ${filePath}")
    val a: Int = git.add().addFilepattern(filePath).call().getEntryCount
    logger.debug(s"Added File Entry Count : ${a}")
  }
//Function for git rm, deletes file/folder from git
  @throws(classOf[Exception])
  def deleteFile(repoName: String, branchName: String, filePath: String, committerId: String,
                 userCommitMessage: String): String = {
    logger.info(s"Deleting File ${filePath} from Repository ${repoName}/${branchName}")
    try {
      this.git.checkout().setName(this.branchName).call
      val myfile: File = new File(localPath + "/" + filePath)
      this.git.rm.addFilepattern(filePath).call
      val commitMsg = (userCommitMessage == null || userCommitMessage.equals("")) match {
        case true => "deleting " + filePath
        case false => userCommitMessage
      }
      this.commit(filePath, commitMsg, committerId)
      this.push
      "Success"
    } catch {
      case e: Exception => {
        logger.error(s"Exception while Deleting File Path ${filePath}")
        this.stash
        throw e
      }
    }
  }
//Function for rolling back any changes , it is invoked if any error happens in the calls which
// modify local repository

  def stash: Unit = {
    this.git.checkout().setName(this.branchName)
    this.git.stashDrop.call
  }

  //functon for git ommit
  @throws(classOf[IOException])
  @throws(classOf[GitAPIException])
  @throws(classOf[JGitInternalException])
  def commit(filePath: String, commitMessage: String, committerId: String) = {
    logger.info(s"Calling Commit with committerId : ${committerId}")
    try {
      this.git.checkout.setName(this.branchName).call
      val commitTime: Int = this.git.commit.setMessage(commitMessage).setOnly(filePath).setCommitter(new PersonIdent(committerId, "")).call().getCommitTime
      logger.debug("Commit time : ${commitTime}")
    } catch {
      case e: Exception => logger.error(s"Error during git commit ${e.getMessage}")
        throw e
    }
  }

  //Function for git push, clled by each function modifying git repo
  @throws(classOf[IOException])
  @throws(classOf[JGitInternalException])
  @throws(classOf[GitAPIException])
  def push = {
    try {
      val remoteString: String = this.git.push().getRemote
      logger.info(s"Calling Push to Remote Repo : ${remoteString}")
      val refSpec: RefSpec = new RefSpec(this.branchName + ":" + this.branchName);
      val results: Iterable[PushResult] = this.git.push.setRefSpecs(refSpec).call
      logger.debug(s"Push Results Size : ${results.size} and their remote Updates")
      for (r <- results) {
        logger.debug(r.getRemoteUpdates.toString)
      }
    } catch {
      case e: Exception => {
        logger.error(s"Exception while pushing ${e.getMessage}")
        throw e
      }
    }
  }
// Function for git save , this function is invoked by end point function
  def save(repoName: String, filePath: String, content: String, userCommitMessage: String, committerId: String): String = {
    logger.info(s"Calling Save on Remote Repo : ${repoName} for File ${filePath}")
    try {
      val myfile: File = new File(localPath + "/" + filePath)
      val uncompressedDir: File = new File(localPath + "/" + filePath.substring(0, filePath.lastIndexOf("/")))
      val tarDir = new File(filePath.substring(filePath.lastIndexOf("/") + 1))
      logger.debug(s"Uncompression Directory : ${uncompressedDir} and Tar Directory ${tarDir}")

      if (tarDir.exists) compressionUtil.delete(tarDir)
      if (!uncompressedDir.exists()) uncompressedDir.mkdirs()

      val fo: FileOutputStream = new FileOutputStream(this.localPath + "/" + filePath + ".tar.gz")
      val bos: BufferedOutputStream = new BufferedOutputStream(fo)
      logger.debug("Gzipped File Path : " + this.localPath + "/" + filePath)
      val b = Base64.getDecoder.decode(content.getBytes)
      bos.write(b)
      //org.apache.commons.io.IOUtils.write(,bos)
      this.update(repoName, filePath, content, userCommitMessage)
      this.commit(filePath, userCommitMessage, committerId)
      this.push
      "Success"
    } catch {
      case e: java.lang.Exception => {
        logger.error(s"Error Saving File ${filePath} to Repository ${repoName}")
        this.stash
        throw e
      }
    }
  }
//Funciton for creating/modifying  local repo
  @throws(classOf[NoFilepatternException])
  @throws(classOf[IOException])
  @throws(classOf[GitAPIException])
  def update(repoName: String, filePath: String, content: String, userCommitMessage: String) = {
    logger.info(s"Calling Update on Remote Repo : ${repoName} for File ${filePath}")
    try {
      this.git.checkout().setName(this.branchName).call
      val myFile: File = new File(localPath + filePath)

      val update = myFile.exists match {
        case true => "updating "
        case false => "creating "
      }

      val commitMsg = (userCommitMessage == null || userCommitMessage.equals("")) match {
        case true => update + filePath
        case false => userCommitMessage
      }

      val uncompressedPath: String = filePath.substring(0, filePath.lastIndexOf("/"))
      val tarDir = filePath.substring(filePath.lastIndexOf("/") + 1)
      logger.info("uncompressedPath:" + uncompressedPath)
      compressionUtil.unCompressTarFile(this.localPath, filePath + ".tar.gz")
      this.git.add().addFilepattern(filePath).call
    } catch {
      case e: NoFilepatternException => {
        logger.error(s"File ${filePath} does not exist")
        throw e
      }
      case e: IOException => {
        logger.error(s"IO exception while updatig file ${filePath} : ${e.getMessage}")
        this.stash
        throw e
      }
    }
  }

  //Funciton for git checkout
  @throws(classOf[GitAPIException])
  def checkout(repoName: String, filePath: String) = {
    logger.info(s"Calling Checkout on Remote Repo : ${repoName} for File ${filePath}")
    git.checkout.addPath(filePath).call
  }

  @throws(classOf[IOException])
  @throws(classOf[JGitInternalException])
  @throws(classOf[GitAPIException])
  def testTrackMaster {
    git.branchCreate.setName("master").setUpstreamMode(SetupUpstreamMode.SET_UPSTREAM).setStartPoint("origin/master").setForce(true).call
  }

// Function for reading git folders/files , invoked by load end point
  @throws(classOf[IOException])
  def load(repoName: String, revSpec: String, path: String): String = {
    logger.info(s"Calling Update on Remote Repo : ${repoName} for revSpec ${revSpec} and Path ${path}")
    this.git.checkout().setName(this.branchName)
    this.pull(repoName)
    val id: ObjectId = this.git.getRepository.resolve(revSpec)
    val reader: ObjectReader = this.git.getRepository.newObjectReader
    var compressedFilePath: String = ""
    var ab: Array[Byte] = Array.empty
    try {
      val tree: RevTree = new RevWalk(reader).parseCommit(id).getTree
      val treewalk: TreeWalk = TreeWalk.forPath(reader, path, tree)
      if (treewalk != null) {
        val objectId = treewalk.getObjectId(0)
        compressedFilePath = compressionUtil.generateCompressedFile(this.localPath, path)
        logger.debug(s"objectId : ${objectId} and compressed file Path : ${compressedFilePath}")
        val loader = new FileInputStream(compressedFilePath)
        try {
          val sz: Int = loader.getChannel.size().asInstanceOf[Int]
          ab = new Array[Byte](sz)
          loader.read(ab)
          reader.close
        } catch {
          case e: Exception => {
            logger.info(s"Exception while loading object ${e.getMessage}")
            throw e
          }
        }
      } else {
        throw new IOException(s"File ${path} does not exist")
      }
    }
    catch {
      case e: IOException => {
        logger.info(s"Problem in reading file ${e.getMessage}")
        throw e
      }
    }
    finally {
      logger.debug(s"Deleting Compressed File Path : ${compressedFilePath}")
      compressionUtil.delete(compressedFilePath)
    }
    new String(Base64.getEncoder.encode(ab))
  }

  //FUnction for getting commitlog for any file or folder
  @throws(classOf[GitAPIException])
  def commitLog(repoName: String, path: String): String = {
    logger.info(s"Calling CommitLog on Remote Repo : ${repoName} for Path ${path}")
    this.git.checkout.setName(this.branchName).call
    var log: util.List[String] = new util.ArrayList[String]()
    try {
      val logs: Iterable[RevCommit] = git.log.addPath(path).call
      for (rev <- logs) {
        val msg = s"Commit id: ${rev.getId.getName}, Committer : ${rev.getCommitterIdent}, Commit Message: ${rev.getFullMessage}"
        logger.debug(msg)
        log.add(msg)
      }
      log.mkString("\n")
    }
    catch {
      case e: Exception => {
        logger.info(s"Exception in commitLog ${e.getMessage}")
        throw e
      }
    }
  }
//Funcition for creating git branch
  @throws(classOf[Exception])
  def createBranch(repoName: String, branchName: String, committerId: String, userCommitMessage: String): String = {
    logger.info(s"Calling createBranch on Remote Repo : ${repoName} for Branch ${branchName}")
    try {
      this.git.checkout.setName("master").call
      this.pull(repoName)
      try {
        this.git.branchCreate.setName(branchName).call
      } catch {
        case e: RefAlreadyExistsException => {
          logger.info(s"Branch ${branchName} already exists")
          return "Success"
        }
      }
      this.git.checkout.setName(branchName).setUpstreamMode(SetupUpstreamMode.TRACK).call
      val refSpec: RefSpec = new RefSpec().setSourceDestination(branchName, branchName)
      val commitMessage = (userCommitMessage == null || userCommitMessage.equals("")) match {
        case true => "creating branch " + branchName
        case false => userCommitMessage
      }
      val commitTime: Int = this.git.commit.setMessage(commitMessage).setCommitter(new PersonIdent(committerId, "")).call().getCommitTime
      logger.debug(s"Create Branch Commit time : ${commitTime}")
      this.git.push.setRemote("origin").setRefSpecs(refSpec).call
    } catch {
      case e: RefAlreadyExistsException => {
        logger.info(s"Branch ${branchName} already exists")
      }
      case e: Exception => {
        logger.error(s"Error while Creating Branch ${branchName} -- ${e.getMessage}")
        throw e
      }
    }
    "Success"
  }

  //Function for deleting branch
  @throws(classOf[Exception])
  def deleteBranch(branchName: String, forceDelete: Boolean, userCommitMessage: String): String = {
    logger.info(s"Calling deleteBranch on Remote Repo : ${repoName} for Branch ${branchName}")
    try {
      val brName = this.git.checkout.setName("master").call.getName
      val delbranch = "refs/remotes/origin/" + branchName
      logger.debug(s"Branch to be Deleted ${delbranch}")
      val deletedBranches = this.git.branchDelete().setBranchNames(delbranch).setForce(forceDelete).call
      val commitMessage = (userCommitMessage == null || userCommitMessage.equals("")) match {
        case true => "deleting branch " + branchName
        case false => userCommitMessage
      }
      this.git.commit.setMessage(commitMessage).setCommitter(new PersonIdent(this.userId, "")).call
      val refSpec: RefSpec = new RefSpec().setSource(null).setDestination(delbranch)
      git.push().setRefSpecs(refSpec).setRemote("origin").call;
      "Success"
    } catch {
      case e: Exception => {
        logger.info(s"Error while Deleting branch ${branchName} -- ${e.getMessage}")
        throw e
      }
    }
  }
//Function for
  @throws(classOf[Exception])
  def listBranches(repoName: String, branchName: String): String = {
    logger.info(s"Calling listBranches on Remote Repo : ${repoName} for Branch ${branchName}")
    try {
      val refs: java.util.List[Ref] = this.git.branchList().setListMode(ListBranchCommand.ListMode.ALL).call
      val refNames: java.util.List[String] = new java.util.ArrayList[String]
      for (ref <- refs) {
        refNames.add(ref.getName)
      }
      refNames.mkString("\n")
    } catch {
      case e: Exception => {
        logger.error(s"Error while Getting Branch list ${e.getMessage}")
        throw e
      }
    }
  }
//Function for merging two  given branches
  @throws(classOf[Exception])
  def merge(fromBranchName: String, toBranchName: String, committerId: String, userCommitMessage: String) = {
    logger.info(s"Calling merge on Remote Repo : ${repoName} from Branch ${fromBranchName} to ${toBranchName}" )
    try {
      this.git.checkout.setName(toBranchName).setUpstreamMode(SetupUpstreamMode.TRACK).call
      val fromRef = this.localRepo.getRef(fromBranchName)
      val mr: MergeResult = this.git.merge.include(this.localRepo.getRef(fromBranchName)).call
      val success: Boolean = mr.getMergeStatus.isSuccessful
      if (!success) {
        logger.debug("merge failed getting conflicts if any")
        var conflicts: String = ""
        mr.getConflicts.foreach(tuple => conflicts = conflicts + "\n" + tuple._1)
        if (!(conflicts == null) && conflicts != "") throw new MergeConflictsException(conflicts)
      }
      else {
        throw new Exception(mr.getMergeStatus.toString)
      }
      val refSpec: RefSpec = new RefSpec().setSourceDestination(branchName, branchName)
      val commitMessage = (userCommitMessage == null || userCommitMessage == "") match {
        case true => "merging  branch " + toBranchName + " with " + fromBranchName
        case false => userCommitMessage
      }
      val commitTime: Int = this.git.commit.setMessage(commitMessage).setCommitter(new PersonIdent(committerId, "")).call().getCommitTime
      logger.debug(s"Merge Commit time ${commitTime}")
      this.git.push.setRemote("origin").setRefSpecs(refSpec).call
    } catch {
      case e: Exception => {
        logger.error(s"Exception while merging ${e.getMessage}")
        this.git.stashDrop.call
        throw e
      }
    }
  }

  /*
  def lockDir(file: File): FileLock = {
    //var lock:FileLock
    val channel: FileChannel = new RandomAccessFile(file, "rw").getChannel
    var lock: FileLock = channel.lock
    try {
      //lock  = channel.lock;
      lock = channel.tryLock
    } catch {
      case e: OverlappingFileLockException => {
        try {
          wait(60)
          lock = channel.tryLock
        }
        catch {
          case e: Exception => {
            logger.info("Exception while acquiring lock on dir " + file + " " + e.getMessage)
          }
        }
      }
      case e: Exception => logger.info("Exception while acquiring lock on dir " + file + " " + e.getMessage)
        throw e
    }
    lock
  }

  def listDirectoryContents(dir: String, depth: Int) = {
    var dirPath = this.localPath + "/" + dir
    this.git.checkout.setName(this.branchName).call
    val head: Ref = this.git.getRepository.getRef("HEAD")
    val walk: RevWalk = new RevWalk(this.git.getRepository)
    val commit: RevCommit = walk.parseCommit(head.getObjectId)
    val tree: RevTree = commit.getTree
    val treeWalk: TreeWalk = new TreeWalk(this.git.getRepository)
    treeWalk.addTree(tree)
    treeWalk.setRecursive(false)
    while (treeWalk.next()) {
      println("found: " + treeWalk.getPathString() + " Level:" + treeWalk.getDepth)
      //   println( treeWalk.getPathString+"::"+ dir)
      if (treeWalk.isSubtree() && treeWalk.getPathString.equals(dir)) {
        println("found dir: " + treeWalk.getPathString() + ":" + treeWalk.getDepth)
        treeWalk.enterSubtree
        treeWalk.setRecursive(true)
        while (treeWalk.next()) {
          println("file/folder:" + treeWalk.getPathString())
        }

      } else if (treeWalk.getPathString == dirPath) {
        System.out.println("file: " + treeWalk.getPathString() + ":" + treeWalk.getDepth)
      }
    }
  }

  @throws(classOf[GitAPIException])
  def listTags: util.List[String] = {
    val versions: List[String] = new ArrayList[String]
    val call: List[Ref] = git.tagList.call
    for (ref <- call) {
      versions.add(ref.getName)
    }
    return versions
  }

  @throws(classOf[IOException])
  @throws(classOf[GitAPIException])
  def diff(tag1: String, tag2: String): List[String] = {
    val diffList: List[String] = new ArrayList[String]
    val tags: Map[String, Ref] = this.git.getRepository.getTags
    val objectId1: ObjectId = tags.get(tag1).getObjectId
    val objectId2: ObjectId = tags.get(tag2).getObjectId
    val repository: Repository = git.getRepository
    try {
      val reader: ObjectReader = repository.newObjectReader
      val oldTreeIter: CanonicalTreeParser = new CanonicalTreeParser
      oldTreeIter.reset(reader, objectId1)
      val newTreeIter: CanonicalTreeParser = new CanonicalTreeParser
      newTreeIter.reset(reader, objectId2)
      try {
        val diffs: List[DiffEntry] = git.diff.setNewTree(newTreeIter).setOldTree(oldTreeIter).call
        for (entry <- diffs) {
          diffList.add("entry from:" + entry.getOldId + ", to" + entry.getNewId)
        }
      }
      catch {
        case e: Exception => {
          logger.error("Error in getting diffs" + e.getMessage)
        }
      }
    }
    catch {
      case e: Exception => {
        System.out.println("Error " + e.getMessage)
      }
    }
    return diffList
  }
  */
}












