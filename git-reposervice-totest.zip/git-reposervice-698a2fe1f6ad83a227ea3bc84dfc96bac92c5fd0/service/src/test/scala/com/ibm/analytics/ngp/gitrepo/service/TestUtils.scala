package com.ibm.analytics.ngp.gitrepo.service
import java.nio.file.{Paths, Files}
import java.util.Base64
import com.ibm.analytics.ngp.gitrepo.service.utils.CompressionUtil
import java.io._
import java.nio.file.Files

/**
 * Created by jcreddy on 31/07/16.
 */
class TestUtils {
     def createFile(tmpFilePath:String,fileContent:String,fileSuffix:String):String= {
      val currTime = System.currentTimeMillis()
      val fileAbsolutePath= Option(fileSuffix) match {
        case None=>s"/tmp/${tmpFilePath}_${currTime}"
        case _=> s"/tmp/${tmpFilePath}_${currTime}.${fileSuffix}"
      }
      val fileHandle = new File(fileAbsolutePath)
      val dirPath = fileHandle.getParent
      val dirHandle = new File(dirPath)
      if (!dirHandle.exists)
        dirHandle.mkdirs
      if (fileHandle.exists)
        fileHandle.delete
      fileHandle.createNewFile()
      Files.write(Paths.get(fileAbsolutePath), fileContent.getBytes)
      fileAbsolutePath
    }

    def createTarFile(gitPath:String,fileContent:String): String =
    {
     val tmpFilePath=createFile(gitPath,fileContent,null)
      val compressionUtil=new CompressionUtil
      compressionUtil.generateCompressedFile("/tmp/",tmpFilePath.split("/tmp/")(1))
      val fileHandle=new File(tmpFilePath)
     if(fileHandle.exists)
      fileHandle.delete
      s"${tmpFilePath}.tar.gz"
     }



  def createEncodedStrig(compressedFilePath:String):String=
  {
    val inputFile=compressedFilePath
    val fi: FileInputStream = new FileInputStream(inputFile)
    val bis: BufferedInputStream = new BufferedInputStream(fi)
    new String(Base64.getEncoder.encode(org.apache.commons.io.IOUtils.toByteArray(bis)))
  }

    def testSave (repoName:String,branchName:String,gitPath:String,fileContent:String,
                    userCommitMessage:String,committerId:String):Boolean=
  {
    val git: GitClient = GitClient(repoName,branchName,committerId)
    git.intialize
    val tempTarFile:String=createTarFile(gitPath,fileContent)
    val stringEncoded=createEncodedStrig(tempTarFile)
    new File(tempTarFile).delete
    git.save(repoName,gitPath,stringEncoded,userCommitMessage,committerId)
    val encodedStringLoaded=git.load(repoName,"HEAD",gitPath)
    git.unInitialize
      encodedStringLoaded.equals(stringEncoded)

  }
    def getDecodedUncompressedString(gitPath:String,encodedFileContent:String):String={
     val absoluteFilePath=createFile(gitPath,encodedFileContent,"tar.gz")
      val compressionUtil=new CompressionUtil
      compressionUtil.unCompressTarFile("/tmp",absoluteFilePath.split("/tmp/")(1))
       val ab:Array[Byte]=new Array[Byte](10000)
      val uncompressedFilePath=absoluteFilePath.split(".tar.gz")(0)
      val fi=new FileInputStream(uncompressedFilePath)
      fi.read(ab)
      if (new File(uncompressedFilePath).exists)
        compressionUtil.delete(uncompressedFilePath)
      new String(ab)
    }

  def testLoad(repoName:String,branchName:String,gitPath:String,revisionSpec:String,refString:String
               ):Boolean=
  {
    val git: GitClient = GitClient(repoName,branchName,"")
    git.intialize
   val encodedString = git.load(repoName,revisionSpec,gitPath)
    val decodedString =Base64.getDecoder.decode(encodedString)
   val uncompressedString= getDecodedUncompressedString(gitPath,encodedString)
    git.unInitialize
    (uncompressedString==refString)
  }

}
