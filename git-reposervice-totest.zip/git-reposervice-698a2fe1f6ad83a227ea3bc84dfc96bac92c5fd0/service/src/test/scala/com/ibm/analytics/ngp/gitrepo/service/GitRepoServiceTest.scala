package com.ibm.analytics.ngp.gitrepo.service

import com.ibm.analytics.ngp.gitrepo.service.utils.CompressionUtil
import org.scalatest.FeatureSpec
import java.io.{FileInputStream, File}

import org.slf4j.LoggerFactory

class GitRepoServiceTest extends FeatureSpec {
  @transient
  private lazy val logger = LoggerFactory.getLogger(classOf[GitRepoServiceTest])
  feature("test compression util funcitons") {
    val compUtils=new CompressionUtil
    val testUtils= new TestUtils
    val fileContent="Test Contents for compress"
    val fileAbsolutePath=testUtils.createFile("gitRepoCompressDir/gitcompressTest",fileContent,null)
    var tarFilePath=""
    scenario("test generate compressed file function") {
      tarFilePath=compUtils.generateCompressedFile("/tmp",fileAbsolutePath.split("/tmp/")(1))
      assert(new File(tarFilePath).exists)
    }

  scenario("test uncompress tar file")
   {
     val fio1=new FileInputStream(fileAbsolutePath)
     val ab1:Array[Byte]= new Array[Byte](10000)
     fio1.read(ab1)
     new File(fileAbsolutePath).delete()
     compUtils.unCompressTarFile("/tmp",s"${tarFilePath}".split("/tmp/")(1))
     val ab2:Array[Byte]= new Array[Byte](10000)
     val fio2=new FileInputStream(fileAbsolutePath)
      fio2.read(ab2)
     var result:Boolean=false
     val File1Content:String = new String(ab1)
     val File2Content2:String = new String(ab2)
     logger.debug("filecontent1="+File1Content)
     logger.debug("filecontent2="+File2Content2)
     assert(File1Content.equals(File2Content2))
   }

    scenario("delete file/folder")
    {
      compUtils.delete(new File(tarFilePath).getParent)
      var result:Boolean=false
      assert (!new File(new File(fileAbsolutePath).getParent).exists)

    }
 }

}


