#!/usr/bin/env bash
export INGEST_HOME=.
if [ ! -d "$INGEST_HOME/logs" ]; then
    mkdir -p "$INGEST_HOME/logs"
fi
export JAVA_HOME=/usr
nohup "$JAVA_HOME/bin/java" -classpath "$INGEST_HOME/target/ingest-service-1.0.0-201603240333-allinone.jar" com.ibm.analytics.microservice.framework.InvokeWorker 12102 > "$INGEST_HOME/logs/worker.log" 2>&1 &
echo $! > "$INGEST_HOME/ingest-service-worker.pid"