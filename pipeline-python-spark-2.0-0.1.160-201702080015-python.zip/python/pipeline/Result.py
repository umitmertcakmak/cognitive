import abc
from pyspark import SparkContext
from pyspark.sql import DataFrame,SQLContext
from pyspark.ml.wrapper import JavaParams

from IBMSparkPipelineModel import IBMSparkPipelineModel
from Wrapper import PythonJavaConversions


class Result(object):
    """
    The absract base class for Result. The `stage` field is a string representing
    the end stage of the DAG.
    """
    __metaclass__ = abc.ABCMeta

    stage = None

class DataResult(Result):
    """
    The DataResult class extends from :class:`Result`. The `data` field is a DataFrame.
    """
    data = None
    _sc = SparkContext._active_spark_context

    def show(self):
        """
        Prints the DataFrame field of DataResult class.

        :return: None
        """
        self.data.show()


class ModelResult(Result):
    """
    The ModelResult class extends from :class:`Result`. The `pipelineModel` field is an object of type
    :class:`pipeline.IBMSparkPipelineModel.IBMSparkPipelineModel`.
    """
    pipelineModel = None

    @classmethod
    def _from_java(cls, java_stage):
        py_stages = [JavaParams._from_java(s) for s in java_stage.stages()]
        # Create a new instance of this stage.
        py_stage = IBMSparkPipelineModel(py_stages)
        py_stage = PythonJavaConversions._resetUid(py_stage, java_stage.uid())
        return py_stage


class SinkResult(Result):
    """
    The SinkResult class extends from :class:`Result`. In case of a SinkResult, only the `stage`
    field is returned.
    """
