import copy
import inspect
from abc import ABCMeta
from py4j.java_collections import JavaArray, JavaList
from py4j.java_collections import ListConverter
from py4j.java_gateway import JavaObject
from py4j.protocol import Py4JJavaError
from pyspark import RDD, SparkContext
from pyspark.ml.param import Params
from pyspark.ml.wrapper import JavaModel
from pyspark.serializers import PickleSerializer, AutoBatchedSerializer
from pyspark.sql import DataFrame, SQLContext



class PythonJavaConversions(object):

    _sc = SparkContext._active_spark_context
    _logSrcLang = "Py:"

    @classmethod
    def _resetUid(cls, stage, uid):

        logger = cls._sc._jvm.org.apache.log4j.Logger.getLogger(cls.__name__)
        methodname = str(inspect.stack()[0][3])
        logMsg = cls._logSrcLang + cls.__name__ + ":" + methodname + ": [Params: " + "stage => " + str(
            stage) + "\" | uid => \"" + str(uid) + "\"]"
        logger.info(logMsg)

        newUid = unicode(uid)
        stage.uid = newUid
        newDefaultParamMap = dict()
        newParamMap = dict()
        for param in stage.params:
            newParam = copy.copy(param)
            newParam.parent = newUid
            if param in stage._defaultParamMap:
                newDefaultParamMap[newParam] = stage._defaultParamMap[param]
            if param in stage._paramMap:
                newParamMap[newParam] = stage._paramMap[param]
            param.parent = newUid
        stage._defaultParamMap = newDefaultParamMap
        stage._paramMap = newParamMap
        return stage

    @classmethod
    def _to_java_stage(cls, stage):
        logger = cls._sc._jvm.org.apache.log4j.Logger.getLogger(cls.__name__)
        methodname = str(inspect.stack()[0][3])
        logMsg = cls._logSrcLang + cls.__name__ + ":" + methodname + ": [Params: " + "stage => " + str(stage) + "]"
        logger.info(logMsg)

        paramMap = stage.extractParamMap()
        for param in stage.params:
            if param in paramMap:
                pair = cls._make_java_param_pair(stage, param, paramMap[param])
                stage._java_obj.set(pair)
        return stage._java_obj

    @classmethod
    def _make_java_param_pair(cls, stage, param, value):
        logger = cls._sc._jvm.org.apache.log4j.Logger.getLogger(cls.__name__)
        methodname = str(inspect.stack()[0][3])
        logMsg = cls._logSrcLang + cls.__name__ + ":" + methodname + ": [Params: " + "stage => " + str(
            stage) + " | param => " + str(param) + " | encoding => " + str(value) + "]"
        logger.info(logMsg)

        param = stage._resolveParam(param)
        java_param = stage._java_obj.getParam(param.name)
        java_value = cls._py2java(cls._sc, value)
        return java_param.w(java_value)

    @staticmethod
    def _to_java_list(java_obj, scala_seq):
        return java_obj.toJavaList(scala_seq)

    @classmethod
    def _load_java_obj(cls, clazz):
        """
        >>> Load the peer Java object of the ML instance.
        """
        # java_class = cls._java_loader_class(clazz)

        logger = cls._sc._jvm.org.apache.log4j.Logger.getLogger(cls.__name__)
        methodname = str(inspect.stack()[0][3])
        logMsg = cls._logSrcLang + cls.__name__ + ":" + methodname + ": [Params: " + "clazz => " + str(clazz) + "]"
        logger.info(logMsg)

        if clazz.__name__ == "IBMSparkPipeline" or clazz.__name__ == "PipelineReader":
            java_class = "com.ibm.analytics.ngp.pipeline.IBMSparkPipeline"

        else:
            java_class = "org.apache.spark.ml.IBMSparkPipelineModel"

        java_obj = cls._sc._jvm
        for name in java_class.split("."):
            java_obj = getattr(java_obj, name)

        return java_obj

