from setuptools import setup

VERSION='0.1.94-201702060843'
setup(name='repository',
      version=VERSION,
      description='Repository Library',
      url='https://github.ibm.com/NGP-TWC/repository/',
      author='IBM',
      author_email='ibm@ibm.com',
      license='IBM',
      packages=[
            'repository',
            'repository.mlrepository',
            'repository.mlrepositoryclient',
            'repository.mlrepositoryartifact',
            'repository.swagger_client',
            'repository.swagger_client.apis',
            'repository.swagger_client.models',
            'repository.util'
      ],
      zip_safe=False)
