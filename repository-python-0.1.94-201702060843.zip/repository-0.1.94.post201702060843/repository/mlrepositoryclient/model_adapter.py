################################################################################
#
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2017
# US Government Users Restricted Rights - Use, duplication disclosure restricted
# by GSA ADP Schedule Contract with IBM Corp.
#
################################################################################


import re
from repository.mlrepository import MetaNames, MetaProps, ModelArtifact
from repository.mlrepositoryartifact import SparkPipelineModelLoader, SparkPipelineModelContentLoader,\
    IBMSparkPipelineModelContentLoader
from repository.util import Json2ObjectMapper


class ModelAdapter(object):
    """
    Adapter creating pipeline model artifact using output from service.
    """
    def __init__(self, model_output, model_version_output, client):
        self.model_output = model_output
        self.model_version_output = model_version_output
        self.client = client
        self.model_type = model_output.entity.type

    def artifact(self):
        if re.match('sparkml-model-\\d+\\.\\d+', self.model_type) is not None:
            model_artifact_builder = type(
                "ModelArtifact",
                (SparkPipelineModelContentLoader, SparkPipelineModelLoader, ModelArtifact, object),
                {}
            )
        elif re.match('ibm-sparkml-model-\d+\.\d+', self.model_type) is not None:
            model_artifact_builder = type(
                "IBMModelArtifact",
                (IBMSparkPipelineModelContentLoader, SparkPipelineModelLoader, ModelArtifact, object),
                {}
            )
        else:
            raise ValueError('Invalid model_type: {}'.format(self.model_type))

        prop_map = {
            MetaNames.MODEL_TYPE: self.model_output.entity.type,
            MetaNames.RUNTIME: self.model_output.entity.runtime_environment
        }

        if self.model_output.metadata.created_at is not None:
            prop_map[MetaNames.CREATION_TIME] = self.model_output.metadata.created_at

        if self.model_output.metadata.modified_at is not None:
            prop_map[MetaNames.LAST_UPDATED] = self.model_output.metadata.modified_at

        if self.model_output.entity.description is not None:
            prop_map[MetaNames.DESCRIPTION] = self.model_output.entity.description

        if self.model_output.entity.label_col is not None:
            prop_map[MetaNames.LABEL_FIELD] = self.model_output.entity.label_col

        if self.model_output.entity.author is not None:
            prop_map[MetaNames.AUTHOR_NAME] = self.model_output.entity.author.name
            prop_map[MetaNames.AUTHOR_EMAIL] = self.model_output.entity.author.email

        if self.model_output.entity.training_data_schema is not None:
            prop_map[MetaNames.TRAINING_DATA_SCHEMA] = self.model_output.entity.training_data_schema

        if self.model_output.entity.input_data_schema is not None:
            prop_map[MetaNames.INPUT_DATA_SCHEMA] = self.model_output.entity.input_data_schema

        model_artifact = model_artifact_builder(
            self.model_output.metadata.guid,
            self.model_output.entity.name,
            MetaProps(prop_map)
        )
        model_artifact._pipeline_version_href = self.model_output.entity.pipeline_version.href
        model_artifact.client = self.client

        if self.model_version_output is not None:
            version_props = MetaProps({
                MetaNames.VERSION: self.model_version_output.metadata.guid,
                MetaNames.MODEL_VERSION_HREF: self.model_version_output.metadata.href,
                MetaNames.PIPELINE_VERSION_HREF: self.model_output.entity.pipeline_version
            })

            training_data_ref = self.model_version_output.entity.training_data_ref
            training_props = MetaProps({
                MetaNames.TRAINING_DATA_REF: training_data_ref if training_data_ref is not None else {}
            })
            version_props.merge(training_props)

            model_artifact.meta.merge(version_props)

            model_artifact._content_href = self.model_version_output.entity.content_href

        else:
            model_artifact._content_href = None

        return model_artifact
