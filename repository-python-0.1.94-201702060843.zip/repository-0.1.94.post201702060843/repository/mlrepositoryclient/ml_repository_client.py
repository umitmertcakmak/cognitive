################################################################################
#
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2017
# US Government Users Restricted Rights - Use, duplication disclosure restricted
# by GSA ADP Schedule Contract with IBM Corp.
#
################################################################################


from model_collection import ModelCollection
from pipeline_collection import PipelineCollection
from repository.ml_api_client import MLApiClient
from repository.ml_authorization import MLAuthorization
from repository.mlrepository.meta_props import MetaProps
from repository.mlrepositoryclient.ml_repository_api import MLRepositoryApi


class MLRepositoryClient(MLAuthorization):
    """
    Main class used as client to connect to Repository sevice.

    :param str base_path: base url to Watson Machine Learning instance
    :param MLApiClient api_client: customized api_client provided by user

    :ivar ModelCollection models: provides client to operate on models
    :ivar PipelineCollection pipelines: provides client to operate on pipelines
    """
    def __init__(self, base_path, api_client=None):
        if api_client is None:
            api_client = MLApiClient(base_path)

        if not isinstance(base_path, str) and not isinstance(base_path, unicode):
            raise ValueError('Invalid type for base_path: {}'.format(base_path.__class__.__name__))

        if not isinstance(api_client, MLApiClient):
            raise ValueError('Invalid type for api_client: {}'.format(api_client.__class__.__name__))

        self.repository_api = MLRepositoryApi(api_client)
        super(MLRepositoryClient, self).__init__(api_client)

        self.models = ModelCollection(base_path, self.repository_api, self)
        self.pipelines = PipelineCollection(base_path, self.repository_api, self)

    @staticmethod
    def meta(self):
        return MetaProps({})
