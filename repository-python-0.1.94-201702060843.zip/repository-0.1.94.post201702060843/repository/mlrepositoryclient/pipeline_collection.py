################################################################################
#
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2017
# US Government Users Restricted Rights - Use, duplication disclosure restricted
# by GSA ADP Schedule Contract with IBM Corp.
#
################################################################################


import logging, re

from repository.mlrepository import MetaNames, PipelineArtifact
from repository.swagger_client.api_client import ApiException
from repository.swagger_client.models import PipelineVersionInput, PipelineVersionOutput,\
    MetaObjectMetadata, PipelineVersionOutputEntity, ArtifactAuthor

from pipeline_adapter import PipelineAdapter
from repository.swagger_client.models.pipeline_input import PipelineInput

logger = logging.getLogger('PipelineCollection')


class PipelineCollection:
    """
    Client operating on pipelines in repository service.

    :param str base_path: base url to Watson Machine Learning instance
    :param MLRepositoryApi repository_api: client connecting to repository rest api
    :param MLRepositoryClient client: high level client used for simplification and argument for constructors
    """
    def __init__(self, base_path, repository_api, client):

        from repository.mlrepositoryclient import MLRepositoryApi, MLRepositoryClient

        if not isinstance(base_path, str) and not isinstance(base_path, unicode):
            raise ValueError('Invalid type for base_path: {}'.format(base_path.__class__.__name__))

        if not isinstance(repository_api, MLRepositoryApi):
            raise ValueError('Invalid type for repository_api: {}'.format(repository_api.__class__.__name__))

        if not isinstance(client, MLRepositoryClient):
            raise ValueError('Invalid type for client: {}'.format(client.__class__.__name__))

        self.base_path = base_path
        self.repository_api = repository_api
        self.client = client

    def all(self):
        """
        Gets info about all pipelines which belong to this user.

        Not complete information is provided by all(). To get detailed information about pipeline use get().

        :return: info about pipelines
        :rtype: list[PipelineArtifact]
        """
        all_pipelines = self.repository_api.get_pipelines()
        if all_pipelines is not None:
            return map(lambda pipeline_data: self._extract_pipeline_from_output(pipeline_data), all_pipelines.resources)
        else:
            return []

    def get(self, artifact_id):
        """
        Gets detailed information about pipeline.

        :param str artifact_id: uid used to identify pipeline
        :return: returned object has all attributes of SparkPipelineArtifact but its class name is PipelineArtifact
        :rtype: PipelineArtifact(SparkPipelineLoader)
        """

        if not isinstance(artifact_id, str):
            raise ValueError('Invalid type for artifact_id: {}'.format(artifact_id.__class__.__name__))

        pipeline_output = self.repository_api.get_pipeline(artifact_id)

        if pipeline_output is not None:
            latest_version = pipeline_output.entity.latest_version

            if latest_version is not None:
                latest_version_output = self.repository_api.get_pipeline_version(artifact_id, latest_version.guid)
            else:
                latest_version_output = None

            return PipelineAdapter(pipeline_output, latest_version_output, self.client).artifact()

        else:
            raise ApiException('Pipeline with guid={} not found'.format(artifact_id))

    def versions(self, artifact_id):
        """
        Gets all available versions.

        Not implemented yet.

        :param str artifact_id: uid used to identify model
        :return: ???
        :rtype: list[str]
        """

        if not isinstance(artifact_id, str):
            raise ValueError('Invalid type for artifact_id: {}'.format(artifact_id.__class__.__name__))

        raise RuntimeError('Not implemented')

    def version(self, artifact_id, ver):
        """
        Gets pipeline version with given artifact_id and ver

        :param str artifact_id: uid used to identify pipeline
        :param str ver: uid used to identify version of pipeline
        :return: returned object has all attributes of SparkPipelineArtifact but its class name is PipelineArtifact
        :rtype: PipelineArtifact(SparkPipelineLoader)
        """

        if not isinstance(artifact_id, str):
            raise ValueError('Invalid type for artifact_id: {}'.format(artifact_id.__class__.__name__))

        if not isinstance(ver, str):
            raise ValueError('Invalid type for ver: {}'.format(ver.__class__.__name__))


        pipeline_version_output = self.repository_api.get_pipeline_version(artifact_id, ver)
        if pipeline_version_output is not None:
            pipeline_output = self.repository_api.get_pipeline(artifact_id)
            if pipeline_output is not None:
                return PipelineAdapter(pipeline_output, pipeline_version_output, self.client).artifact()
            else:
                raise Exception('Model with guid={} not found'.format(artifact_id))
        else:
            raise Exception('Model with guid={} not found'.format(artifact_id))

    def version_from_href(self, artifact_version_href):
        """
        Gets pipeline version from given href

        :param str artifact_version_href: href identifying artifact and version
        :return: returned object has all attributes of SparkPipelineArtifact but its class name is PipelineArtifact
        :rtype: PipelineArtifact(SparkPipelineLoader)
        """

        if not isinstance(artifact_version_href, str):
            raise ValueError('Invalid type for artifact_version_href: {}'.format(artifact_version_href.__class__.__name__))

        if artifact_version_href.startswith(self.base_path):
            matched = re.search(
                '.*/v2/artifacts/pipelines/([A-Za-z0-9\-]+)/versions/([A-Za-z0-9\-]+)', artifact_version_href)
            if matched is not None:
                artifact_id = matched.group(1)
                version_id = matched.group(2)
                return self.version(artifact_id, version_id)
            else:
                raise ValueError('Unexpected artifact version href: {} format'.format(artifact_version_href))
        else:
            raise ValueError('The artifact version href: {} is not within the client host: {}').format(
                artifact_version_href,
                self.base_path
            )

    def remove(self, artifact_id):
        """
        Removes pipeline with given artifact_id.

        :param str artifact_id: uid used to identify pipeline
        """

        if not isinstance(artifact_id, str):
            raise ValueError('Invalid type for artifact_id: {}'.format(artifact_id.__class__.__name__))

        return self.repository_api.delete_pipeline(artifact_id)

    def save(self, artifact):
        """
        Saves pipeline in repository service.

        :param SparkPipelineArtifact artifact: artifact to be saved in the repository service
        :return: saved artifact with changed MetaProps
        :rtype: SparkPipelineArtifact
        """
        logger.debug('Creating a new pipeline: {}'.format(artifact.name))

        if not issubclass(type(artifact), PipelineArtifact):
            raise ValueError('Invalid type for artifact: {}'.format(artifact.__class__.__name__))

        if artifact.meta.prop(MetaNames.PIPELINE_VERSION_HREF) is not None:
            raise ApiException(400, 'Invalid operation: save the same pipeline artifact twice')

        try:
            pipeline_id = artifact.uid
            if pipeline_id is None:
                pipeline_input = self._get_pipeline_input(artifact)
                r = self.repository_api.create_pipeline_with_http_info(pipeline_input)
                location = r[2].get('Location')
                location_match = re.search('.*/v2/artifacts/pipelines/([A-Za-z0-9\\-]+)', location)

                if location_match is not None:
                    pipeline_id = location_match.group(1)
                else:
                    logger.error('Error while creating pipeline: no location header')
                    raise ApiException(204, 'No artifact location')

            if pipeline_id is not None:
                artifact_with_guid = artifact._copy(pipeline_id)
                logger.debug('Creating a new version for pipeline: {}'.format(pipeline_id))
                pipeline_version_input = self._get_version_input(artifact)
                r = self.repository_api.create_pipeline_version_with_http_info(pipeline_id, pipeline_version_input)
                location = r[2].get('Location')

                if location is not None:
                    new_version_artifact = self.version_from_href(location)
                    version_id = new_version_artifact.meta.prop(MetaNames.VERSION)

                    content_stream = artifact_with_guid.reader().read()
                    self.repository_api.upload_pipeline_version(pipeline_id, version_id, content_stream)
                    content_stream.close()
                    artifact_with_guid.reader().close()
                    return new_version_artifact
                else:
                    logger.error('Error while creating pipeline version: no location header')
                    raise ApiException(204, 'No artifact location')
            else:
                raise ApiException(404, 'Pipeline not found')

        except Exception as e:
            logger.error('Error in pipeline creation')
            raise e

    def _extract_pipeline_from_output(self, service_output):
        latest_version = service_output.entity.latest_version
        if latest_version is not None:
            latest_version_output = PipelineVersionOutput(
                MetaObjectMetadata(latest_version.guid, latest_version.href, None, None),
                PipelineVersionOutputEntity(latest_version.content_href, None)
            )
        else:
            latest_version_output = None
        return PipelineAdapter(service_output, latest_version_output, self.client).artifact()

    @staticmethod
    def _get_pipeline_input(artifact):
        return PipelineInput(
            artifact.name,
            artifact.meta.prop(MetaNames.DESCRIPTION),
            ArtifactAuthor(
                artifact.meta.prop(MetaNames.AUTHOR_NAME),
                artifact.meta.prop(MetaNames.AUTHOR_EMAIL)
            ),
            artifact.meta.prop(MetaNames.PIPELINE_TYPE),
            artifact.meta.prop(MetaNames.RUNTIME)
        )

    @staticmethod
    def _get_version_input(artifact):
        return PipelineVersionInput(artifact.meta.prop(MetaNames.PARENT_VERSION))
