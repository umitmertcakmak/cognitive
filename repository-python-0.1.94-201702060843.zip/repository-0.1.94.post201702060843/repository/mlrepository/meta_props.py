################################################################################
#
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2017
# US Government Users Restricted Rights - Use, duplication disclosure restricted
# by GSA ADP Schedule Contract with IBM Corp.
#
################################################################################


class MetaProps:
    """
    Holder for props used during creation of ML artifacts.

    As keys are used values from MetaNames.

    Description of keys:

    +--------------------------------+---------+---------+---------+--------+-------------------------------------------------+
    |Key name                        |User     |Used with|Used with|Optional|Description                                      |
    |                                |specified|pipeline |model    |        |                                                 |
    +================================+=========+=========+=========+========+=================================================+
    |MetaNames.CREATION_TIME         |No       |Yes      |Yes      |--      |time of creating artifact in repository service  |
    +--------------------------------+---------+---------+---------+--------+-------------------------------------------------+
    |MetaNames.LAST_UPDATED          |No       |Yes      |Yes      |--      |time of last update of this artifact             |
    |                                |         |         |         |        |in repository service                            |
    +--------------------------------+---------+---------+---------+--------+-------------------------------------------------+
    |MetaNames.TRAINING_DATA_REF     |Yes      |No       |Yes      |Yes     |reference to training data for model             |
    +--------------------------------+---------+---------+---------+--------+-------------------------------------------------+
    |MetaNames.TRAINING_DATA_SCHEMA  |No       |No       |Yes      |--      |schema of training data passed during creation   |
    |                                |         |         |         |        |of model artifact                                |
    +--------------------------------+---------+---------+---------+--------+-------------------------------------------------+
    |MetaNames.INPUT_DATA_SCHEMA     |Yes      |No       |Yes      |Yes     |input schema for model, should be set by user    |
    |                                |         |         |         |        |if creating input schema from training schema    |
    |                                |         |         |         |        |and labelCol is impossible                       |
    +--------------------------------+---------+---------+---------+--------+-------------------------------------------------+
    |MetaNames.LABEL_FIELD           |No       |No       |Yes      |--      |information about model what is the name         |
    |                                |         |         |         |        |of output column (labelCol)                      |
    +--------------------------------+---------+---------+---------+--------+-------------------------------------------------+
    |MetaNames.PARENT_VERSION        |No       |Yes      |Yes      |--      |href to previous version of artifact             |
    +--------------------------------+---------+---------+---------+--------+-------------------------------------------------+
    |MetaNames.VERSION               |No       |Yes      |Yes      |--      |id of version of artifact                        |
    +--------------------------------+---------+---------+---------+--------+-------------------------------------------------+
    |MetaNames.RUNTIME               |No       |Yes      |Yes      |--      |runtime which will be used by scoring services   |
    |                                |         |         |         |        |to run this artifact                             |
    +--------------------------------+---------+---------+---------+--------+-------------------------------------------------+
    |MetaNames.MODEL_METRICS         |--       |No       |Yes      |--      |modelMetrics                                     |
    +--------------------------------+---------+---------+---------+--------+-------------------------------------------------+
    |MetaNames.EVALUATION_METHOD     |--       |No       |Yes      |--      |evaluationMethod                                 |
    +--------------------------------+---------+---------+---------+--------+-------------------------------------------------+
    |MetaNames.EVALUATION_METRICS    |--       |No       |Yes      |--      |evaluationMetrics                                |
    +--------------------------------+---------+---------+---------+--------+-------------------------------------------------+
    |MetaNames.MODEL_TYPE            |No       |No       |Yes      |--      |model type, used only with models                |
    +--------------------------------+---------+---------+---------+--------+-------------------------------------------------+
    |MetaNames.PIPELINE_TYPE         |No       |Yes      |No       |--      |pipeline type, used only with pipelines          |
    +--------------------------------+---------+---------+---------+--------+-------------------------------------------------+
    |MetaNames.DESCRIPTION           |Yes      |Yes      |Yes      |Yes     |description prepared by user                     |
    +--------------------------------+---------+---------+---------+--------+-------------------------------------------------+
    |MetaNames.MODEL_VERSION_HREF    |No       |No       |Yes      |--      |href to version of this model in repository      |
    |                                |         |         |         |        |service, used only with models                   |
    +--------------------------------+---------+---------+---------+--------+-------------------------------------------------+
    |MetaNames.PIPELINE_VERSION_HREF |No       |Yes      |No       |--      |href to version of this pipeline in repository   |
    |                                |         |         |         |        |service, used only with pipelines                |
    +--------------------------------+---------+---------+---------+--------+-------------------------------------------------+
    |MetaNames.AUTHOR_NAME           |Yes      |Yes      |Yes      |Yes     |name of author                                   |
    +--------------------------------+---------+---------+---------+--------+-------------------------------------------------+
    |MetaNames.AUTHOR_EMAIL          |Yes      |Yes      |Yes      |Yes     |email of author                                  |
    +--------------------------------+---------+---------+---------+--------+-------------------------------------------------+

    :param map meta: Map of pair key and value where key is taken from MetaNames.
    """
    def __init__(self, meta):
        self.meta = meta

    def available_props(self):
        """Return list of strings with names of available props."""
        return self.meta.keys()

    def prop(self, name):
        """Get prop value by name."""
        return self.meta.get(name)

    def merge(self, other):
        """Merge other MetaProp object to first one. Modify first MetaProp object, doesn't return anything."""
        self.meta.update(other.meta)

    def add(self, name, value):
        """
        Add new prop.

        :param str name: Key for value. Should be one of the values from MetaNames.
        :param object value: Any type of object
        """
        self.meta[name] = value
