################################################################################
#
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2017
# US Government Users Restricted Rights - Use, duplication disclosure restricted
# by GSA ADP Schedule Contract with IBM Corp.
#
################################################################################


class MetaNames(object):
    """
    Holder for constants used by MetaProps.

    """
    CREATION_TIME = "creationTime"
    LAST_UPDATED = "lastUpdated"
    TRAINING_DATA_REF = "trainingDataRef"
    TRAINING_DATA_SCHEMA = "trainingDataSchema"
    INPUT_DATA_SCHEMA = "inputDataSchema"
    LABEL_FIELD = "label"
    PARENT_VERSION = "parentVersion"
    VERSION = "version"
    RUNTIME = "runtime"
    MODEL_METRICS = "modelMetrics"
    EVALUATION_METHOD = "evaluationMethod"
    EVALUATION_METRICS = "evaluationMetrics"
    MODEL_TYPE = "modelType"
    PIPELINE_TYPE = "pipelineType"
    DESCRIPTION = "description"
    MODEL_VERSION_HREF = "modelVersionHref"
    PIPELINE_VERSION_HREF = "pipelineVersionHref"
    AUTHOR_NAME = "authorName"
    AUTHOR_EMAIL = "authorEmail"
