################################################################################
#
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2017
# US Government Users Restricted Rights - Use, duplication disclosure restricted
# by GSA ADP Schedule Contract with IBM Corp.
#
################################################################################


from pyspark.ml import Pipeline, PipelineModel


class SparkPipelineContentLoader(object):
    @staticmethod
    def load_content(content_dir):
        return Pipeline.read().load(content_dir)


class IBMSparkPipelineContentLoader(object):
    @staticmethod
    def load_content(content_dir):
        from pipeline import IBMSparkPipeline
        return IBMSparkPipeline.read().load(content_dir)


class SparkPipelineModelContentLoader(object):
    @staticmethod
    def load_content(content_dir):
        return PipelineModel.read().load(content_dir)


class IBMSparkPipelineModelContentLoader(object):
    @staticmethod
    def load_content(content_dir):
        from pipeline import IBMSparkPipelineModel
        return IBMSparkPipelineModel.read().load(content_dir)