################################################################################
#
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2017
# US Government Users Restricted Rights - Use, duplication disclosure restricted
# by GSA ADP Schedule Contract with IBM Corp.
#
################################################################################


from spark_version import SparkVersion


class VersionHelper(object):
    @staticmethod
    def significant():
        import pipeline
        version_parts = [int(version_part) for version_part in pipeline.__version__.split('.')]
        return "{}.{}".format(version_parts[0], version_parts[1])

    @staticmethod
    def pipeline_type(ml_pipeline):
        canonical_name = ml_pipeline.__class__.__name__
        if canonical_name == 'Pipeline':
            return 'sparkml-pipeline-{}'.format(SparkVersion.significant())
        elif canonical_name == 'IBMSparkPipeline':
            return 'ibm-sparkml-pipeline-{}'.format(VersionHelper.significant())
        else:
            raise ValueError('Unsupported Pipeline class: {}'.format(canonical_name))

    @staticmethod
    def model_type(ml_pipeline_model):
        class_name = ml_pipeline_model.__class__.__name__
        if class_name == 'PipelineModel':
            return 'sparkml-model-{}'.format(SparkVersion.significant())
        elif class_name == 'IBMSparkPipelineModel':
            return 'ibm-sparkml-model-{}'.format(VersionHelper.significant())
        else:
            raise ValueError('Unsupported PipelineModel class: {}'.format(class_name))