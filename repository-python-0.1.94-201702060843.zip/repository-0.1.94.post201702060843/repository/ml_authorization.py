################################################################################
#
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2017
# US Government Users Restricted Rights - Use, duplication disclosure restricted
# by GSA ADP Schedule Contract with IBM Corp.
#
################################################################################


import certifi
import json

try:
    import urllib3
except ImportError:
    raise ImportError('urllib3 is missing')

try:
    # for python3
    from urllib.parse import urlencode
except ImportError:
    # for python2
    from urllib import urlencode

http = urllib3.PoolManager(
    cert_reqs='CERT_REQUIRED',
    ca_certs=certifi.where()
)


class MLAuthorization(object):
    """
    Class used to authorize user.

    MLAuthorization shouldn't be used alone. It is created to be used as a base class by MLRepositoryClient.
    """
    def __init__(self, api_client):
        self.api_client = api_client

    def _add_header(self, key, value):
        self.api_client.set_default_header(key, value)
        self.api_client.set_default_header(key, value)

    def authorize(self, user, password):
        """
        Authorizes user by username and password

        Both username and password should be credentials taken from Watson Machine Learning instance.

        :param str user: username taken from WML instance
        :param str password: password corresponding with user name taken from WML instance

        """
        headers = urllib3.util.make_headers(basic_auth='{}:{}'.format(user, password))
        url = '{}/v2/identity/token'.format(self.api_client.repository_path)
        response = http.request(
            'GET',
            url,
            headers=headers
        )
        token = json.loads(response.data).get('token')
        self.authorize_with_token(token)

    def authorize_with_token(self, token):
        """
            Authorizes user by token.

            Token should be generated during basic authentication using username and password from WML service instance.

            :param str user: token

            """
        self._add_header('Authorization', 'Bearer {}'.format(token))
